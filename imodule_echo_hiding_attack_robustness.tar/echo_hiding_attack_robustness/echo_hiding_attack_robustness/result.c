#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_current_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

double read_ber(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return -1.0;

    char line[1024];
    double ber = -1.0;

    while (fgets(line, sizeof(line), fp)) {
        if (strncmp(line, "BER:", 4) == 0) {
            ber = atof(line + 4);
            break;
        }
    }

    fclose(fp);
    return ber;
}

void to_lower_str(char *s) {
    for (int i = 0; s[i]; i++) {
        s[i] = tolower((unsigned char)s[i]);
    }
}

int answer_contains_required_terms() {
    FILE *fp = fopen("answer.txt", "r");
    if (!fp) return 0;

    char all[8192] = "";
    char line[1024];

    while (fgets(line, sizeof(line), fp)) {
        if (strlen(all) + strlen(line) < sizeof(all) - 1) {
            strcat(all, line);
        }
    }

    fclose(fp);
    to_lower_str(all);

    return strstr(all, "task 1") &&
           strstr(all, "task 2") &&
           strstr(all, "task 3") &&
           strstr(all, "ber") &&
           strstr(all, "noise") &&
           strstr(all, "resample") &&
           strstr(all, "lowpass");
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int embedding_extraction =
        file_exists("stego.wav") &&
        file_exists("stego.wav.meta") &&
        file_exists("extracted_before.txt") &&
        file_has_current_nonce("stego.wav.meta", nonce) &&
        file_has_current_nonce("extracted_before.txt", nonce) &&
        log_has_step("embed input=cover.wav") &&
        log_has_step("extract input=stego.wav");

    int attacks_generated =
        file_exists("attacked_noise.wav") &&
        file_exists("attacked_noise.wav.meta") &&
        file_exists("attacked_resample.wav") &&
        file_exists("attacked_resample.wav.meta") &&
        file_exists("attacked_lowpass.wav") &&
        file_exists("attacked_lowpass.wav.meta") &&
        file_has_current_nonce("attacked_noise.wav.meta", nonce) &&
        file_has_current_nonce("attacked_resample.wav.meta", nonce) &&
        file_has_current_nonce("attacked_lowpass.wav.meta", nonce) &&
        log_has_step("attack input=stego.wav output=attacked_noise.wav mode=noise") &&
        log_has_step("attack input=stego.wav output=attacked_resample.wav mode=resample") &&
        log_has_step("attack input=stego.wav output=attacked_lowpass.wav mode=lowpass");

    int ber_reports =
        file_exists("extracted_noise.txt") &&
        file_exists("extracted_resample.txt") &&
        file_exists("extracted_lowpass.txt") &&
        file_exists("ber_noise.txt") &&
        file_exists("ber_resample.txt") &&
        file_exists("ber_lowpass.txt") &&
        file_has_current_nonce("extracted_noise.txt", nonce) &&
        file_has_current_nonce("extracted_resample.txt", nonce) &&
        file_has_current_nonce("extracted_lowpass.txt", nonce) &&
        file_has_current_nonce("ber_noise.txt", nonce) &&
        file_has_current_nonce("ber_resample.txt", nonce) &&
        file_has_current_nonce("ber_lowpass.txt", nonce) &&
        log_has_step("ber reference=message.txt test=extracted_noise.txt") &&
        log_has_step("ber reference=message.txt test=extracted_resample.txt") &&
        log_has_step("ber reference=message.txt test=extracted_lowpass.txt");

    double ber_noise = read_ber("ber_noise.txt");
    double ber_resample = read_ber("ber_resample.txt");
    double ber_lowpass = read_ber("ber_lowpass.txt");

    int attack_analysis =
        ber_noise >= 0.0 &&
        ber_resample >= 0.0 &&
        ber_lowpass >= 0.0 &&
        (ber_noise > 0.0 || ber_resample > 0.0 || ber_lowpass > 0.0);

    if (embedding_extraction) {
        emit_hidden_token("embedding_extraction_completed");
    }

    if (attacks_generated) {
        emit_hidden_token("attacks_generated_current_run");
    }

    if (ber_reports) {
        emit_hidden_token("ber_reports_generated");
    }

    if (attack_analysis) {
        emit_hidden_token("attack_analysis_completed");
    }

    if (answer_contains_required_terms()) {
        emit_hidden_token("answer_file_completed");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
