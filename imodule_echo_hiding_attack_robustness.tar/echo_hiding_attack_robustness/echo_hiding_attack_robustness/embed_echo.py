#!/usr/bin/env python3
import argparse
import wave
import numpy as np
from lab_common import read_nonce, write_step

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def write_wav(path, rate, x):
    x = x / (np.max(np.abs(x)) + 1e-12) * 0.90
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm.tobytes())

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", required=True)
    p.add_argument("-m", "--message", required=True)
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    p.add_argument("--alpha", type=float, default=0.45)
    args = p.parse_args()

    rate, x = read_wav(args.input)

    with open(args.message, "r", encoding="utf-8") as f:
        msg = f.read().strip()

    bits = text_to_bits(msg)
    seg_len = len(x) // len(bits)

    if seg_len <= max(args.delay0, args.delay1) + 10:
        raise ValueError("Audio is too short for this message.")

    y = x.copy()

    for i, bit in enumerate(bits):
        start = i * seg_len
        end = start + seg_len
        delay = args.delay1 if bit else args.delay0

        y[start + delay:end] += args.alpha * x[start:end - delay]

    write_wav(args.output, rate, y)

    nonce = read_nonce()
    with open(args.output + ".meta", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Message: {args.message}\n")
        f.write(f"Output: {args.output}\n")
        f.write(f"Embedded bits: {len(bits)}\n")

    write_step(f"embed input={args.input} message={args.message} output={args.output} nonce={nonce}")

    print("Embedding completed.")
    print(f"Message length: {len(msg)} characters")
    print(f"Embedded bits: {len(bits)}")
    print(f"Output: {args.output}")

if __name__ == "__main__":
    main()
