#!/usr/bin/env python3
import argparse
import wave
import numpy as np
from lab_common import read_nonce, write_step

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def cep_score(seg, delay):
    seg = seg - np.mean(seg)
    seg = seg * np.hanning(len(seg))
    nfft = 1
    while nfft < len(seg):
        nfft *= 2

    spec = np.fft.rfft(seg, n=nfft)
    log_mag = np.log(np.abs(spec) + 1e-12)
    cep = np.fft.irfft(log_mag, n=nfft)
    return abs(cep[delay])

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        value = 0
        for b in byte:
            value = (value << 1) | b
        chars.append(value)

    return bytes(chars).decode("utf-8", errors="replace")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", required=True)
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--chars", type=int, default=15)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    args = p.parse_args()

    rate, x = read_wav(args.input)
    bit_count = args.chars * 8
    seg_len = len(x) // bit_count

    bits = []

    for i in range(bit_count):
        start = i * seg_len
        end = start + seg_len
        seg = x[start:end]

        s0 = cep_score(seg, args.delay0)
        s1 = cep_score(seg, args.delay1)

        bits.append(1 if s1 > s0 else 0)

    text = bits_to_text(bits)
    bit_string = "".join(str(b) for b in bits)

    nonce = read_nonce()

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Extracted text: {text}\n")
        f.write(f"Bits: {bit_string}\n")

    write_step(f"extract input={args.input} output={args.output} nonce={nonce}")

    print("Extraction completed.")
    print(f"Output: {args.output}")
    print(f"Extracted text: {text}")

if __name__ == "__main__":
    main()
