#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

if [ ! -f cover.wav ] || [ ! -f message.txt ]; then
    python3 generate_materials.py > /tmp/generate_materials.log 2>&1
fi

chmod +x generate_materials.py 2>/dev/null
chmod +x embed_echo.py 2>/dev/null
chmod +x extract_echo.py 2>/dev/null
chmod +x attack_audio.py 2>/dev/null
chmod +x ber_check.py 2>/dev/null
