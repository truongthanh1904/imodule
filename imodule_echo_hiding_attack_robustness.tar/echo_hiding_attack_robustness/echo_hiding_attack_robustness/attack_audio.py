#!/usr/bin/env python3
import argparse
import wave
import numpy as np
from lab_common import read_nonce, write_step

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def write_wav(path, rate, x):
    x = x / (np.max(np.abs(x)) + 1e-12) * 0.90
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm.tobytes())

def add_noise(x, snr_db):
    rng = np.random.default_rng(1234)
    signal_power = np.mean(x ** 2)
    noise_power = signal_power / (10 ** (snr_db / 10))
    noise = rng.normal(0, np.sqrt(noise_power), len(x))
    return x + noise

def resample_down_up(x, factor=2):
    down = x[::factor]
    up = np.repeat(down, factor)

    if len(up) < len(x):
        up = np.pad(up, (0, len(x) - len(up)))
    return up[:len(x)]

def lowpass_moving_average(x, window=21):
    kernel = np.ones(window) / window
    return np.convolve(x, kernel, mode="same")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", required=True)
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--mode", required=True, choices=["noise", "resample", "lowpass"])
    p.add_argument("--snr", type=float, default=10.0)
    p.add_argument("--factor", type=int, default=2)
    p.add_argument("--window", type=int, default=21)
    args = p.parse_args()

    rate, x = read_wav(args.input)

    if args.mode == "noise":
        y = add_noise(x, args.snr)
    elif args.mode == "resample":
        y = resample_down_up(x, args.factor)
    else:
        y = lowpass_moving_average(x, args.window)

    write_wav(args.output, rate, y)

    nonce = read_nonce()
    with open(args.output + ".meta", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Mode: {args.mode}\n")
        f.write(f"Output: {args.output}\n")

    write_step(f"attack input={args.input} output={args.output} mode={args.mode} nonce={nonce}")

    print("Attack completed.")
    print(f"Mode: {args.mode}")
    print(f"Output: {args.output}")

if __name__ == "__main__":
    main()
