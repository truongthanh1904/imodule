#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def read_reference(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()

def read_extracted(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            if line.startswith("Extracted text:"):
                return line.split(":", 1)[1].strip()
    return ""

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-r", "--reference", required=True)
    p.add_argument("-t", "--test", required=True)
    p.add_argument("-o", "--output", required=True)
    args = p.parse_args()

    ref_text = read_reference(args.reference)
    test_text = read_extracted(args.test)

    ref_bits = text_to_bits(ref_text)
    test_bits = text_to_bits(test_text)

    n = min(len(ref_bits), len(test_bits))
    if n == 0:
        errors = len(ref_bits)
        ber = 1.0
    else:
        errors = sum(1 for i in range(n) if ref_bits[i] != test_bits[i])
        errors += abs(len(ref_bits) - len(test_bits))
        ber = errors / len(ref_bits)

    nonce = read_nonce()

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Reference: {ref_text}\n")
        f.write(f"Extracted: {test_text}\n")
        f.write(f"Bit errors: {errors}\n")
        f.write(f"Total bits: {len(ref_bits)}\n")
        f.write(f"BER: {ber:.4f}\n")

    write_step(f"ber reference={args.reference} test={args.test} output={args.output} ber={ber:.4f} nonce={nonce}")

    print("BER check completed.")
    print(f"Output: {args.output}")
    print(f"BER: {ber:.4f}")

if __name__ == "__main__":
    main()
