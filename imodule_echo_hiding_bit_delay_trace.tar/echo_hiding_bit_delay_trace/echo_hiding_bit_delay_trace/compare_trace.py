#!/usr/bin/env python3
import argparse
import csv
from lab_common import read_nonce, write_step

def read_bits_from_map(path):
    bits = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = sorted(reader, key=lambda r: int(r["bit_index_global"]))
        for row in rows:
            bits.append(int(row["bit"]))
    return bits

def read_bits_from_trace(path):
    bits = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = sorted(reader, key=lambda r: int(r["bit_index_global"]))
        for row in rows:
            bits.append(int(row["recovered_bit"]))
    return bits

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--embed-map", default="bit_delay_map.csv")
    p.add_argument("--extract-trace", default="extraction_trace.csv")
    p.add_argument("--message", default="message.txt")
    p.add_argument("--extracted", default="extracted_message.txt")
    p.add_argument("--output", default="trace_compare_report.txt")
    args = p.parse_args()

    nonce = read_nonce()

    embed_bits = read_bits_from_map(args.embed_map)
    extract_bits = read_bits_from_trace(args.extract_trace)

    total = min(len(embed_bits), len(extract_bits))
    errors = sum(1 for i in range(total) if embed_bits[i] != extract_bits[i])
    ber = errors / total if total else 1.0

    with open(args.message, "r", encoding="utf-8") as f:
        original_message = f.read().strip()

    with open(args.extracted, "r", encoding="utf-8", errors="replace") as f:
        extracted_message = f.read().strip()

    trace_matched = errors == 0 and original_message == extracted_message

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Original message: {original_message}\n")
        f.write(f"Extracted message: {extracted_message}\n")
        f.write(f"Total bits: {total}\n")
        f.write(f"Bit errors: {errors}\n")
        f.write(f"BER: {ber:.4f}\n")
        f.write(f"Trace matched: {'yes' if trace_matched else 'no'}\n")

    write_step(
        f"compare_trace map={args.embed_map} trace={args.extract_trace} "
        f"output={args.output} nonce={nonce} ber={ber:.4f}"
    )

    print("Trace comparison completed.")
    print(f"BER: {ber:.4f}")
    print(f"Trace matched: {'yes' if trace_matched else 'no'}")

if __name__ == "__main__":
    main()
