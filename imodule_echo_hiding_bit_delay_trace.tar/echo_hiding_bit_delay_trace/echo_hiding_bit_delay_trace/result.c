#include <stdio.h>
#include <string.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[4096];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_current_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[4096];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int cover_generated =
        file_exists("cover.wav") &&
        file_exists("message.txt") &&
        file_exists("generate_report.txt") &&
        file_has_current_nonce("generate_report.txt", nonce) &&
        file_contains("generate_report.txt", "Message: PTIT ECHO") &&
        file_contains("generate_report.txt", "Cover generated: yes") &&
        log_has_step("generate_cover cover=cover.wav");

    int algorithm_reviewed =
        file_exists("algorithm_review.txt") &&
        file_has_current_nonce("algorithm_review.txt", nonce) &&
        file_contains("algorithm_review.txt", "Algorithm reviewed: yes") &&
        file_contains("algorithm_review.txt", "bit 0 -> delay0") &&
        log_has_step("review_algorithm");

    int bit_delay_map =
        file_exists("bit_delay_map.csv") &&
        file_exists("bit_trace_report.txt") &&
        file_has_current_nonce("bit_trace_report.txt", nonce) &&
        file_contains("bit_trace_report.txt", "Message: PTIT ECHO") &&
        file_contains("bit_trace_report.txt", "Total bits: 72") &&
        file_contains("bit_trace_report.txt", "Delay0: 50") &&
        file_contains("bit_trace_report.txt", "Delay1: 75") &&
        file_contains("bit_trace_report.txt", "Bit-delay map completed: yes") &&
        file_contains("bit_delay_map.csv", "bit_index_global") &&
        file_contains("bit_delay_map.csv", ",50") &&
        file_contains("bit_delay_map.csv", ",75") &&
        log_has_step("trace_bits message=message.txt");

    int echo_embedded =
        file_exists("stego.wav") &&
        file_exists("embed_info.txt") &&
        file_has_current_nonce("embed_info.txt", nonce) &&
        file_contains("embed_info.txt", "Payload bits: 72") &&
        file_contains("embed_info.txt", "Delays used: 50,75") &&
        file_contains("embed_info.txt", "Embedding completed: yes") &&
        log_has_step("embed_trace cover=cover.wav");

    int extraction_trace =
        file_exists("extracted_message.txt") &&
        file_exists("extraction_trace.csv") &&
        file_exists("extraction_info.txt") &&
        file_has_current_nonce("extraction_info.txt", nonce) &&
        file_contains("extraction_info.txt", "Extracted message: PTIT ECHO") &&
        file_contains("extraction_info.txt", "Extraction completed: yes") &&
        file_contains("extraction_trace.csv", "score_delay0") &&
        file_contains("extraction_trace.csv", "score_delay1") &&
        log_has_step("extract_trace input=stego.wav");

    int trace_verified =
        file_exists("trace_compare_report.txt") &&
        file_has_current_nonce("trace_compare_report.txt", nonce) &&
        file_contains("trace_compare_report.txt", "Original message: PTIT ECHO") &&
        file_contains("trace_compare_report.txt", "Extracted message: PTIT ECHO") &&
        file_contains("trace_compare_report.txt", "Total bits: 72") &&
        file_contains("trace_compare_report.txt", "Bit errors: 0") &&
        file_contains("trace_compare_report.txt", "BER: 0.0000") &&
        file_contains("trace_compare_report.txt", "Trace matched: yes") &&
        log_has_step("compare_trace map=bit_delay_map.csv");

    int wrong_delay_test =
        file_exists("wrong_delay_message.txt") &&
        file_exists("wrong_delay_trace.csv") &&
        file_exists("wrong_delay_info.txt") &&
        file_has_current_nonce("wrong_delay_info.txt", nonce) &&
        file_contains("wrong_delay_info.txt", "Delay0: 45") &&
        file_contains("wrong_delay_info.txt", "Delay1: 80") &&
        log_has_step("extract_trace input=stego.wav output=wrong_delay_message.txt");

    if (cover_generated) {
        emit_hidden_token("cover_generated");
    }

    if (algorithm_reviewed) {
        emit_hidden_token("algorithm_reviewed");
    }

    if (bit_delay_map) {
        emit_hidden_token("bit_delay_map_completed");
    }

    if (echo_embedded) {
        emit_hidden_token("echo_embedded");
    }

    if (extraction_trace) {
        emit_hidden_token("extraction_trace_completed");
    }

    if (trace_verified) {
        emit_hidden_token("trace_verified");
    }

    if (wrong_delay_test) {
        emit_hidden_token("wrong_delay_test_completed");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
