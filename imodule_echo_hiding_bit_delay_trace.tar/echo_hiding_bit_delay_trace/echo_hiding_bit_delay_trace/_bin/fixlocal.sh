#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

chmod +x generate_cover.py 2>/dev/null
chmod +x review_algorithm.py 2>/dev/null
chmod +x trace_bits.py 2>/dev/null
chmod +x embed_trace.py 2>/dev/null
chmod +x extract_trace.py 2>/dev/null
chmod +x compare_trace.py 2>/dev/null
