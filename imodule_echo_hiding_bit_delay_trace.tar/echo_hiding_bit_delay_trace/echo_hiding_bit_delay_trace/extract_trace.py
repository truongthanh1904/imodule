#!/usr/bin/env python3
import argparse
import csv
from lab_common import read_nonce, write_step
from echo_tools import read_wav, real_cepstrum, bits_to_text

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", default="stego.wav")
    p.add_argument("--chars", type=int, default=9)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    p.add_argument("--output", default="extracted_message.txt")
    p.add_argument("--trace", default="extraction_trace.csv")
    p.add_argument("--info", default="extraction_info.txt")
    args = p.parse_args()

    nonce = read_nonce()

    rate, audio = read_wav(args.input)

    bit_count = args.chars * 8
    seg_len = len(audio) // bit_count

    bits = []
    rows = []

    for bit_index in range(bit_count):
        start = bit_index * seg_len
        end = start + seg_len
        seg = audio[start:end]

        cep = real_cepstrum(seg)

        score0 = abs(cep[args.delay0])
        score1 = abs(cep[args.delay1])

        recovered_bit = 1 if score1 > score0 else 0
        selected_delay = args.delay1 if recovered_bit else args.delay0

        bits.append(recovered_bit)

        rows.append({
            "bit_index_global": bit_index,
            "segment": bit_index,
            "score_delay0": f"{score0:.8f}",
            "score_delay1": f"{score1:.8f}",
            "recovered_bit": recovered_bit,
            "selected_delay": selected_delay
        })

    message = bits_to_text(bits)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(message + "\n")

    with open(args.trace, "w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "bit_index_global",
            "segment",
            "score_delay0",
            "score_delay1",
            "recovered_bit",
            "selected_delay"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    with open(args.info, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Chars: {args.chars}\n")
        f.write(f"Delay0: {args.delay0}\n")
        f.write(f"Delay1: {args.delay1}\n")
        f.write(f"Output: {args.output}\n")
        f.write(f"Trace: {args.trace}\n")
        f.write(f"Extracted message: {message}\n")
        f.write("Extraction completed: yes\n")

    write_step(
        f"extract_trace input={args.input} output={args.output} trace={args.trace} "
        f"nonce={nonce} chars={args.chars} delay0={args.delay0} delay1={args.delay1}"
    )

    print("Extraction trace completed.")
    print(f"Extracted message: {message}")
    print(f"Trace: {args.trace}")

if __name__ == "__main__":
    main()
