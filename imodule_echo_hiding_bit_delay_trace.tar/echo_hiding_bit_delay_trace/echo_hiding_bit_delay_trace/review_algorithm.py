#!/usr/bin/env python3
from lab_common import read_nonce, write_step

TEXT = """
Echo Hiding algorithm trace

Basic model:
  y(n) = x(n) + alpha * x(n - d)

Bit mapping:
  bit 0 -> delay0
  bit 1 -> delay1

In this lab:
  delay0 = 50 samples
  delay1 = 75 samples

Workflow:
  message text
  -> ASCII bytes
  -> bit stream
  -> one segment per bit
  -> echo delay selected by bit value
  -> stego.wav
  -> cepstrum-based extraction
  -> recovered bit stream
  -> recovered message

The purpose is to observe the algorithm at bit level, not only run embed/extract as a black box.
"""

def main():
    nonce = read_nonce()
    print(f"Run nonce: {nonce}")
    print(TEXT.strip())

    with open("algorithm_review.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(TEXT.strip() + "\n")
        f.write("Algorithm reviewed: yes\n")

    write_step(f"review_algorithm nonce={nonce}")

if __name__ == "__main__":
    main()
