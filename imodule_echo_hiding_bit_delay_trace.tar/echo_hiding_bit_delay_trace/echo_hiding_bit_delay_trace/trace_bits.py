#!/usr/bin/env python3
import argparse
import csv
from lab_common import read_nonce, write_step

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--message", default="message.txt")
    p.add_argument("--output", default="bit_delay_map.csv")
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.message, "r", encoding="utf-8") as f:
        text = f.read().strip()

    rows = []
    global_bit = 0

    for char_index, ch in enumerate(text):
        ascii_value = ord(ch)

        for bit_index_in_char in range(8):
            bit = (ascii_value >> (7 - bit_index_in_char)) & 1
            delay = args.delay1 if bit else args.delay0

            rows.append({
                "char_index": char_index,
                "char": ch,
                "ascii": ascii_value,
                "bit_index_global": global_bit,
                "bit_index_in_char": bit_index_in_char,
                "bit": bit,
                "segment": global_bit,
                "delay": delay
            })

            global_bit += 1

    with open(args.output, "w", encoding="utf-8", newline="") as f:
        fieldnames = [
            "char_index",
            "char",
            "ascii",
            "bit_index_global",
            "bit_index_in_char",
            "bit",
            "segment",
            "delay"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    with open("bit_trace_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Message: {text}\n")
        f.write(f"Message length: {len(text)}\n")
        f.write(f"Total bits: {len(rows)}\n")
        f.write(f"Delay0: {args.delay0}\n")
        f.write(f"Delay1: {args.delay1}\n")
        f.write(f"Output map: {args.output}\n")
        f.write("Bit-delay map completed: yes\n")

    write_step(
        f"trace_bits message={args.message} output={args.output} "
        f"nonce={nonce} bits={len(rows)} delay0={args.delay0} delay1={args.delay1}"
    )

    print("Bit-delay map completed.")
    print(f"Message: {text}")
    print(f"Total bits: {len(rows)}")
    print(f"Output: {args.output}")

if __name__ == "__main__":
    main()
