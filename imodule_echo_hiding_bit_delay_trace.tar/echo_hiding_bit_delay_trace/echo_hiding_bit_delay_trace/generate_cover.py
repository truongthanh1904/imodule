#!/usr/bin/env python3
import wave
import numpy as np
from lab_common import read_nonce, write_step

RATE = 16000
DURATION = 8.0
MESSAGE = "PTIT ECHO"

def normalize(x, peak=0.85):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())

def main():
    nonce = read_nonce()

    rng = np.random.default_rng(9090)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    x = (
        0.36 * np.sin(2 * np.pi * 440 * t) +
        0.24 * np.sin(2 * np.pi * 880 * t) +
        0.12 * np.sin(2 * np.pi * 1760 * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.25 * t)
    x = x * envelope
    x = x + 0.025 * rng.standard_normal(n)

    write_wav("cover.wav", x)

    with open("message.txt", "w", encoding="utf-8") as f:
        f.write(MESSAGE)

    with open("generate_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write("Cover file: cover.wav\n")
        f.write("Message file: message.txt\n")
        f.write(f"Message: {MESSAGE}\n")
        f.write(f"Sample rate: {RATE}\n")
        f.write(f"Duration seconds: {DURATION:.2f}\n")
        f.write("Cover generated: yes\n")

    write_step(f"generate_cover cover=cover.wav message=message.txt nonce={nonce}")

    print("Generated cover.wav and message.txt")
    print(f"Message: {MESSAGE}")

if __name__ == "__main__":
    main()
