#!/usr/bin/env python3
import argparse
import csv
from lab_common import read_nonce, write_step
from echo_tools import read_wav, write_wav, normalize

def read_map(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({
                "bit_index_global": int(row["bit_index_global"]),
                "segment": int(row["segment"]),
                "bit": int(row["bit"]),
                "delay": int(row["delay"])
            })
    rows.sort(key=lambda r: r["bit_index_global"])
    return rows

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cover", default="cover.wav")
    p.add_argument("--map", default="bit_delay_map.csv")
    p.add_argument("--output", default="stego.wav")
    p.add_argument("--alpha", type=float, default=0.42)
    args = p.parse_args()

    nonce = read_nonce()
    rows = read_map(args.map)

    rate, audio = read_wav(args.cover)
    seg_len = len(audio) // len(rows)

    if seg_len <= max(r["delay"] for r in rows) + 10:
        raise ValueError("Segment length is too short for selected delays.")

    stego = audio.copy()

    for row in rows:
        start = row["segment"] * seg_len
        end = start + seg_len
        delay = row["delay"]

        stego[start + delay:end] += args.alpha * audio[start:end-delay]

    write_wav(args.output, rate, normalize(stego))

    delays = sorted(set(r["delay"] for r in rows))

    with open("embed_info.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Cover: {args.cover}\n")
        f.write(f"Map: {args.map}\n")
        f.write(f"Output: {args.output}\n")
        f.write(f"Alpha: {args.alpha:.2f}\n")
        f.write(f"Payload bits: {len(rows)}\n")
        f.write(f"Segment length: {seg_len}\n")
        f.write(f"Delays used: {','.join(str(d) for d in delays)}\n")
        f.write("Embedding completed: yes\n")

    write_step(
        f"embed_trace cover={args.cover} map={args.map} output={args.output} "
        f"nonce={nonce} alpha={args.alpha:.2f} bits={len(rows)}"
    )

    print("Echo embedding completed.")
    print(f"Output: {args.output}")
    print(f"Payload bits: {len(rows)}")
    print(f"Segment length: {seg_len}")

if __name__ == "__main__":
    main()
