#!/usr/bin/env python3
import argparse
import wave
import numpy as np

def read_wav_mono(path):
    with wave.open(path, "rb") as wf:
        channels = wf.getnchannels()
        width = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if width != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    data = np.frombuffer(frames, dtype=np.int16).astype(np.float64)

    if channels > 1:
        data = data.reshape(-1, channels).mean(axis=1)

    return rate, data / 32768.0

def real_cepstrum(x):
    x = x - np.mean(x)
    x = x * np.hanning(len(x))

    nfft = 1
    while nfft < len(x):
        nfft *= 2

    spec = np.fft.rfft(x, n=nfft)
    log_mag = np.log(np.abs(spec) + 1e-12)
    cep = np.fft.irfft(log_mag, n=nfft)
    return cep

def detect(cep, delay_min, delay_max, delay0, delay1, threshold):
    region = np.abs(cep[delay_min:delay_max + 1])
    median = np.median(region) + 1e-12

    peak_index = int(np.argmax(region))
    peak_delay = delay_min + peak_index
    peak_score = float(region[peak_index] / median)

    delay0_score = float(abs(cep[delay0]) / median)
    delay1_score = float(abs(cep[delay1]) / median)

    detected = peak_score >= threshold or delay0_score >= threshold or delay1_score >= threshold

    return peak_delay, peak_score, delay0_score, delay1_score, detected

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", required=True)
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--delay-min", type=int, default=45)
    p.add_argument("--delay-max", type=int, default=85)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    p.add_argument("--threshold", type=float, default=6.0)
    args = p.parse_args()

    rate, x = read_wav_mono(args.input)
    cep = real_cepstrum(x)

    peak_delay, peak_score, d0_score, d1_score, detected = detect(
        cep,
        args.delay_min,
        args.delay_max,
        args.delay0,
        args.delay1,
        args.threshold
    )

    decision = "echo_hiding_detected" if detected else "clean"

    nonce = ""
    try:
        with open(".lab_nonce", "r", encoding="utf-8") as nf:
            nonce = nf.read().strip()
    except FileNotFoundError:
        nonce = "missing_nonce"

    lines = [
        f"Run nonce: {nonce}",
        f"Input: {args.input}",
        f"Sample rate: {rate} Hz",
        f"Search region: {args.delay_min}-{args.delay_max} samples",
        f"Expected delay0: {args.delay0} samples",
        f"Expected delay1: {args.delay1} samples",
        f"Peak delay: {peak_delay} samples",
        f"Peak score: {peak_score:.2f}",
        f"Delay0 score: {d0_score:.2f}",
        f"Delay1 score: {d1_score:.2f}",
        f"Decision: {decision}"
    ]

    with open(args.output, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print("\n".join(lines))

    try:
        import os
        os.makedirs(".local", exist_ok=True)
        with open(".local/lab_steps.log", "a", encoding="utf-8") as log:
            log.write(f"detect_cepstrum input={args.input} output={args.output} nonce={nonce} decision={decision}\n")
    except Exception:
        pass

if __name__ == "__main__":
    main()
