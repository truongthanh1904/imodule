#!/usr/bin/env python3
import wave
import numpy as np

RATE = 16000
DURATION = 4.0

def normalize(x, peak=0.90):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())

def base_signal(seed):
    rng = np.random.default_rng(seed)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    x = (
        0.45 * np.sin(2 * np.pi * 437 * t) +
        0.25 * np.sin(2 * np.pi * 1234 * t) +
        0.10 * np.sin(2 * np.pi * 2567 * t)
    )

    envelope = 0.7 + 0.3 * np.sin(2 * np.pi * 2.3 * t)
    x = x * envelope
    x = x + 0.04 * rng.standard_normal(n)
    return normalize(x)

def add_echo_hiding(x, alpha=0.35):
    y = x.copy()
    seg_len = 4000
    bits = [0, 1, 0, 1, 1, 0, 0, 1,
            0, 1, 1, 1, 0, 0, 1, 0]

    for i, bit in enumerate(bits):
        start = i * seg_len
        end = min(start + seg_len, len(x))
        if start >= len(x):
            break

        delay = 50 if bit == 0 else 75

        if end - start > delay:
            y[start + delay:end] += alpha * x[start:end - delay]

    return normalize(y, peak=0.92)

def main():
    clean = base_signal(seed=11)
    suspect_01 = base_signal(seed=21)
    suspect_02 = add_echo_hiding(base_signal(seed=31), alpha=0.35)
    suspect_03 = add_echo_hiding(base_signal(seed=41), alpha=0.25)

    write_wav("clean.wav", clean)
    write_wav("suspect_01.wav", suspect_01)
    write_wav("suspect_02.wav", suspect_02)
    write_wav("suspect_03.wav", suspect_03)

    print("Generated clean.wav, suspect_01.wav, suspect_02.wav, suspect_03.wav")

if __name__ == "__main__":
    main()
