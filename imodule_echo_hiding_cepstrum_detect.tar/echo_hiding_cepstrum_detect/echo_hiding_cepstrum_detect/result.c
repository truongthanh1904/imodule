#include <stdio.h>
#include <string.h>
#include <ctype.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int report_has_current_nonce(const char *report, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(report, expected);
}

int log_has_step(const char *input_name) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "detect_cepstrum") && strstr(line, input_name)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void to_lower_str(char *s) {
    for (int i = 0; s[i]; i++) {
        s[i] = tolower((unsigned char)s[i]);
    }
}

int answer_contains_required_terms() {
    FILE *fp = fopen("answer.txt", "r");
    if (!fp) return 0;

    char all[8192] = "";
    char line[1024];

    while (fgets(line, sizeof(line), fp)) {
        if (strlen(all) + strlen(line) < sizeof(all) - 1) {
            strcat(all, line);
        }
    }

    fclose(fp);
    to_lower_str(all);

    return strstr(all, "suspect_02") &&
           strstr(all, "suspect_03") &&
           strstr(all, "echo");
}

/*
 * Ghi token ra stdout để Labtainer checkwork đọc được,
 * nhưng dùng escape sequence để xoá khỏi màn hình terminal.
 */
void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int reports_exist =
        file_exists("clean_report.txt") &&
        file_exists("suspect_01_report.txt") &&
        file_exists("suspect_02_report.txt") &&
        file_exists("suspect_03_report.txt");

    int reports_current =
        report_has_current_nonce("clean_report.txt", nonce) &&
        report_has_current_nonce("suspect_01_report.txt", nonce) &&
        report_has_current_nonce("suspect_02_report.txt", nonce) &&
        report_has_current_nonce("suspect_03_report.txt", nonce);

    int steps_done =
        log_has_step("clean.wav") &&
        log_has_step("suspect_01.wav") &&
        log_has_step("suspect_02.wav") &&
        log_has_step("suspect_03.wav");

    int correct_detection =
        file_contains("clean_report.txt", "Decision: clean") &&
        file_contains("suspect_01_report.txt", "Decision: clean") &&
        file_contains("suspect_02_report.txt", "Decision: echo_hiding_detected") &&
        file_contains("suspect_03_report.txt", "Decision: echo_hiding_detected");

    if (reports_exist && reports_current && steps_done) {
        emit_hidden_token("reports_generated_current_run");
    }

    if (correct_detection) {
        emit_hidden_token("correct_detection_results");
    }

    if (answer_contains_required_terms()) {
        emit_hidden_token("answer_file_completed");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
