#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

if [ ! -f clean.wav ] || [ ! -f suspect_01.wav ] || [ ! -f suspect_02.wav ] || [ ! -f suspect_03.wav ]; then
    python3 generate_audio.py > /tmp/generate_audio.log 2>&1
fi

chmod +x generate_audio.py 2>/dev/null
chmod +x detect_cepstrum.py 2>/dev/null
