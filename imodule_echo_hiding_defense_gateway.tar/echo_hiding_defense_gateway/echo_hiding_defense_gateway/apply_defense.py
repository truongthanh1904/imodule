#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step
from echo_tools import read_wav, write_wav, normalize
import numpy as np

def echo_cancel(audio, delay0, delay1, beta):
    y = audio.copy()

    for delay in [delay0, delay1]:
        cleaned = y.copy()
        cleaned[delay:] = cleaned[delay:] - beta * y[:-delay]
        y = cleaned

    return normalize(y)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", default="incoming_suspect.wav")
    p.add_argument("-d", "--delay-report", default="delay_report.txt")
    p.add_argument("-o", "--output", default="sanitized.wav")
    p.add_argument("--beta", type=float, default=0.42)
    args = p.parse_args()

    nonce = read_nonce()

    delay0 = None
    delay1 = None

    with open(args.delay_report, "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("Estimated delay0:"):
                delay0 = int(line.split(":", 1)[1].strip())
            if line.startswith("Estimated delay1:"):
                delay1 = int(line.split(":", 1)[1].strip())

    if delay0 is None or delay1 is None:
        raise ValueError("Could not read estimated delays from delay_report.txt")

    rate, audio = read_wav(args.input)
    cleaned = echo_cancel(audio, delay0, delay1, args.beta)
    write_wav(args.output, rate, cleaned)

    with open("defense_apply_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Output: {args.output}\n")
        f.write(f"Applied delay0: {delay0}\n")
        f.write(f"Applied delay1: {delay1}\n")
        f.write(f"Beta: {args.beta:.2f}\n")
        f.write("Defense applied: yes\n")

    write_step(
        f"apply_defense input={args.input} output={args.output} "
        f"nonce={nonce} delay0={delay0} delay1={delay1} beta={args.beta:.2f}"
    )

    print("Defense applied.")
    print(f"Output: {args.output}")
    print(f"Applied delay0: {delay0}")
    print(f"Applied delay1: {delay1}")

if __name__ == "__main__":
    main()
