#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step
from echo_tools import read_wav, snr_db

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-r", "--reference", default="clean_reference.wav")
    p.add_argument("-i", "--input", default="sanitized.wav")
    p.add_argument("-o", "--output", default="quality_report.txt")
    p.add_argument("--min-snr", type=float, default=7.0)
    args = p.parse_args()

    nonce = read_nonce()

    rate_ref, ref = read_wav(args.reference)
    rate_in, audio = read_wav(args.input)

    if rate_ref != rate_in:
        raise ValueError("Sample rates do not match.")

    score = snr_db(ref, audio)
    acceptable = score >= args.min_snr

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Reference: {args.reference}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"SNR dB: {score:.4f}\n")
        f.write(f"Minimum SNR dB: {args.min_snr:.4f}\n")
        f.write(f"Quality acceptable: {'yes' if acceptable else 'no'}\n")

    write_step(
        f"quality_check reference={args.reference} input={args.input} "
        f"output={args.output} nonce={nonce} acceptable={'yes' if acceptable else 'no'} snr={score:.4f}"
    )

    print("Quality check completed.")
    print(f"Output: {args.output}")
    print(f"SNR dB: {score:.4f}")
    print(f"Quality acceptable: {'yes' if acceptable else 'no'}")

if __name__ == "__main__":
    main()
