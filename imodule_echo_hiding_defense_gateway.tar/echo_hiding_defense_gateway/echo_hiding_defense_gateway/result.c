#include <stdio.h>
#include <string.h>
#include <ctype.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_current_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int leakage_confirmed =
        file_exists("leakage_report.txt") &&
        file_has_current_nonce("leakage_report.txt", nonce) &&
        file_contains("leakage_report.txt", "Leakage confirmed: yes") &&
        log_has_step("confirm_leakage input=incoming_suspect.wav");

    int delay_estimated =
        file_exists("delay_report.txt") &&
        file_has_current_nonce("delay_report.txt", nonce) &&
        file_contains("delay_report.txt", "Delay estimation valid: yes") &&
        log_has_step("estimate_delay input=incoming_suspect.wav");

    int defense_applied =
        file_exists("sanitized.wav") &&
        file_exists("defense_apply_report.txt") &&
        file_has_current_nonce("defense_apply_report.txt", nonce) &&
        file_contains("defense_apply_report.txt", "Defense applied: yes") &&
        log_has_step("apply_defense input=incoming_suspect.wav");

    int defense_verified =
        file_exists("defense_report.txt") &&
        file_has_current_nonce("defense_report.txt", nonce) &&
        file_contains("defense_report.txt", "Defense verified: yes") &&
        log_has_step("verify_defense input=sanitized.wav");

    int quality_checked =
        file_exists("quality_report.txt") &&
        file_has_current_nonce("quality_report.txt", nonce) &&
        file_contains("quality_report.txt", "Quality acceptable: yes") &&
        log_has_step("quality_check reference=clean_reference.wav");

    if (leakage_confirmed) {
        emit_hidden_token("leakage_confirmed");
    }

    if (delay_estimated) {
        emit_hidden_token("delay_estimated");
    }

    if (defense_applied) {
        emit_hidden_token("defense_applied");
    }

    if (defense_verified) {
        emit_hidden_token("defense_verified");
    }

    if (quality_checked) {
        emit_hidden_token("quality_checked");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
