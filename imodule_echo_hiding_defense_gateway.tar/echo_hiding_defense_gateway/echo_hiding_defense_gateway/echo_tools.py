#!/usr/bin/env python3
import wave
import numpy as np

def normalize(x, peak=0.90):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)

    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def write_wav(path, rate, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm.tobytes())

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break

        value = 0
        for b in byte:
            value = (value << 1) | b

        chars.append(value)

    return bytes(chars).decode("utf-8", errors="replace")

def real_cepstrum(x):
    x = x - np.mean(x)
    x = x * np.hanning(len(x))

    nfft = 1
    while nfft < len(x):
        nfft *= 2

    spec = np.fft.rfft(x, n=nfft)
    log_mag = np.log(np.abs(spec) + 1e-12)
    return np.fft.irfft(log_mag, n=nfft)

def extract_message(audio, chars, delay0=50, delay1=75):
    bit_count = chars * 8
    seg_len = len(audio) // bit_count
    bits = []

    for i in range(bit_count):
        start = i * seg_len
        end = start + seg_len
        seg = audio[start:end]

        cep = real_cepstrum(seg)
        s0 = abs(cep[delay0])
        s1 = abs(cep[delay1])

        bits.append(1 if s1 > s0 else 0)

    return bits_to_text(bits)

def aggregate_cepstrum(audio, chars):
    bit_count = chars * 8
    seg_len = len(audio) // bit_count
    acc = None

    for i in range(bit_count):
        start = i * seg_len
        end = start + seg_len
        seg = audio[start:end]
        cep = np.abs(real_cepstrum(seg))

        if acc is None:
            acc = cep
        else:
            acc += cep

    return acc / bit_count

def snr_db(reference, test):
    n = min(len(reference), len(test))
    reference = reference[:n]
    test = test[:n]
    noise = test - reference

    signal_power = np.mean(reference ** 2)
    noise_power = np.mean(noise ** 2) + 1e-12

    return 10 * np.log10(signal_power / noise_power)
