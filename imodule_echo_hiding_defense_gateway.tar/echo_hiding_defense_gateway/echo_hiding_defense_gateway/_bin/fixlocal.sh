#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

if [ ! -f incoming_suspect.wav ] || [ ! -f clean_reference.wav ] || [ ! -f reference_message.txt ]; then
    python3 generate_materials.py > /tmp/generate_materials.log 2>&1
fi

chmod +x generate_materials.py 2>/dev/null
chmod +x confirm_leakage.py 2>/dev/null
chmod +x estimate_delay.py 2>/dev/null
chmod +x apply_defense.py 2>/dev/null
chmod +x verify_defense.py 2>/dev/null
chmod +x quality_check.py 2>/dev/null
