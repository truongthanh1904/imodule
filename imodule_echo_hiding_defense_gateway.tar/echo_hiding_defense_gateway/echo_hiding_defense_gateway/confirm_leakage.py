#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step
from echo_tools import read_wav, extract_message

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", default="incoming_suspect.wav")
    p.add_argument("-r", "--reference", default="reference_message.txt")
    p.add_argument("-o", "--output", default="leakage_report.txt")
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.reference, "r", encoding="utf-8") as f:
        expected = f.read().strip()

    rate, audio = read_wav(args.input)
    extracted = extract_message(audio, len(expected), args.delay0, args.delay1)

    confirmed = extracted == expected

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Reference: {expected}\n")
        f.write(f"Extracted text: {extracted}\n")
        f.write(f"Leakage confirmed: {'yes' if confirmed else 'no'}\n")

    write_step(
        f"confirm_leakage input={args.input} output={args.output} "
        f"nonce={nonce} leakage={'yes' if confirmed else 'no'}"
    )

    print("Leakage confirmation completed.")
    print(f"Output: {args.output}")
    print(f"Leakage confirmed: {'yes' if confirmed else 'no'}")

if __name__ == "__main__":
    main()
