#!/usr/bin/env python3
import wave
import numpy as np

RATE = 16000
DURATION = 8.0
MESSAGE = "GATEWAY_LEAK"

def normalize(x, peak=0.85):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def embed_echo(x, message, alpha=0.45, delay0=50, delay1=75):
    bits = text_to_bits(message)
    seg_len = len(x) // len(bits)
    y = x.copy()

    for i, bit in enumerate(bits):
        start = i * seg_len
        end = start + seg_len
        delay = delay1 if bit else delay0
        y[start + delay:end] += alpha * x[start:end-delay]

    return normalize(y)

def main():
    rng = np.random.default_rng(5050)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    cover = (
        0.38 * np.sin(2 * np.pi * 440 * t) +
        0.22 * np.sin(2 * np.pi * 880 * t) +
        0.14 * np.sin(2 * np.pi * 1760 * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.2 * t)
    cover = cover * envelope
    cover = cover + 0.025 * rng.standard_normal(n)
    cover = normalize(cover)

    suspect = embed_echo(cover, MESSAGE)

    write_wav("incoming_suspect.wav", suspect)
    write_wav("clean_reference.wav", cover)

    with open("reference_message.txt", "w", encoding="utf-8") as f:
        f.write(MESSAGE)

    print("Generated incoming_suspect.wav, clean_reference.wav and reference_message.txt")

if __name__ == "__main__":
    main()
