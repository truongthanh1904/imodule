#!/usr/bin/env python3
import argparse
import numpy as np
from lab_common import read_nonce, write_step
from echo_tools import read_wav, aggregate_cepstrum

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", default="incoming_suspect.wav")
    p.add_argument("-r", "--reference", default="reference_message.txt")
    p.add_argument("-o", "--output", default="delay_report.txt")
    p.add_argument("--delay-min", type=int, default=45)
    p.add_argument("--delay-max", type=int, default=85)
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.reference, "r", encoding="utf-8") as f:
        message = f.read().strip()

    rate, audio = read_wav(args.input)
    cep = aggregate_cepstrum(audio, len(message))

    region = np.abs(cep[args.delay_min:args.delay_max + 1])
    median = np.median(region) + 1e-12

    ranked = np.argsort(region)[::-1]
    top_delays = []
    for idx in ranked:
        delay = args.delay_min + int(idx)
        if all(abs(delay - d) >= 5 for d in top_delays):
            top_delays.append(delay)
        if len(top_delays) == 2:
            break

    top_delays = sorted(top_delays)
    d0 = top_delays[0]
    d1 = top_delays[1]

    score0 = abs(cep[d0]) / median
    score1 = abs(cep[d1]) / median

    valid = (
        args.delay_min <= d0 <= args.delay_max and
        args.delay_min <= d1 <= args.delay_max and
        score0 >= 3.0 and
        score1 >= 3.0
    )

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Search range: {args.delay_min}-{args.delay_max}\n")
        f.write(f"Estimated delay0: {d0}\n")
        f.write(f"Estimated delay1: {d1}\n")
        f.write(f"Delay0 score: {score0:.4f}\n")
        f.write(f"Delay1 score: {score1:.4f}\n")
        f.write(f"Delay estimation valid: {'yes' if valid else 'no'}\n")

    write_step(
        f"estimate_delay input={args.input} output={args.output} "
        f"nonce={nonce} delay0={d0} delay1={d1} valid={'yes' if valid else 'no'}"
    )

    print("Delay estimation completed.")
    print(f"Output: {args.output}")
    print(f"Estimated delay0: {d0}")
    print(f"Estimated delay1: {d1}")
    print(f"Delay estimation valid: {'yes' if valid else 'no'}")

if __name__ == "__main__":
    main()
