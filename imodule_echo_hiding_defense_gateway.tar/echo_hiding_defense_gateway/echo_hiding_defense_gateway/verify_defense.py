#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step
from echo_tools import read_wav, extract_message

def similarity(a, b):
    n = min(len(a), len(b))
    if n == 0:
        return 0.0
    same = sum(1 for i in range(n) if a[i] == b[i])
    return same / max(len(a), len(b))

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", default="sanitized.wav")
    p.add_argument("-r", "--reference", default="reference_message.txt")
    p.add_argument("-o", "--output", default="defense_report.txt")
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.reference, "r", encoding="utf-8") as f:
        expected = f.read().strip()

    rate, audio = read_wav(args.input)
    extracted = extract_message(audio, len(expected), args.delay0, args.delay1)

    sim = similarity(expected, extracted)
    blocked = extracted != expected and sim < 0.75

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Reference: {expected}\n")
        f.write(f"Extracted after defense: {extracted}\n")
        f.write(f"Similarity: {sim:.4f}\n")
        f.write(f"Defense verified: {'yes' if blocked else 'no'}\n")

    write_step(
        f"verify_defense input={args.input} output={args.output} "
        f"nonce={nonce} verified={'yes' if blocked else 'no'} similarity={sim:.4f}"
    )

    print("Defense verification completed.")
    print(f"Output: {args.output}")
    print(f"Defense verified: {'yes' if blocked else 'no'}")

if __name__ == "__main__":
    main()
