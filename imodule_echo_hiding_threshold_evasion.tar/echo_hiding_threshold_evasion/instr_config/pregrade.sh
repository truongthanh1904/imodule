#!/bin/bash

homedir=$1
destdir=$2

work="$homedir/$destdir"
cd "$work" || exit 1

mkdir -p .local/result
out=.local/result/result.stdout

find_one() {
    find . -type f -name "$1" | head -n 1
}

clean_report=$(find_one clean_report.txt)
suspect_01_report=$(find_one suspect_01_report.txt)
suspect_02_report=$(find_one suspect_02_report.txt)
suspect_03_report=$(find_one suspect_03_report.txt)
answer_file=$(find_one answer.txt)

{
    echo "Labname echo_hiding_threshold_evasion"
    echo

    [ -n "$clean_report" ] && echo "clean_report_present"
    [ -n "$suspect_01_report" ] && echo "suspect_01_report_present"
    [ -n "$suspect_02_report" ] && echo "suspect_02_report_present"
    [ -n "$suspect_03_report" ] && echo "suspect_03_report_present"

    grep -q "Decision: clean" "$clean_report" 2>/dev/null && echo "clean_wav_clean"
    grep -q "Decision: clean" "$suspect_01_report" 2>/dev/null && echo "suspect_01_wav_clean"
    grep -q "Decision: echo_hiding_detected" "$suspect_02_report" 2>/dev/null && echo "suspect_02_wav_echo_hiding"
    grep -q "Decision: echo_hiding_detected" "$suspect_03_report" 2>/dev/null && echo "suspect_03_wav_echo_hiding"

    ans=$(tr 'A-Z' 'a-z' < "$answer_file" 2>/dev/null)

    echo "$ans" | grep -q "suspect_02" && echo "$ans" | grep -q "echo" && echo "answer_suspect_02_echo"
    echo "$ans" | grep -q "suspect_03" && echo "$ans" | grep -q "echo" && echo "answer_suspect_03_echo"

    echo
    echo "What is automatically assessed for this lab:"
} > "$out"
