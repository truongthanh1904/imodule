#include <stdio.h>
#include <string.h>
#include <ctype.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_current_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void to_lower_str(char *s) {
    for (int i = 0; s[i]; i++) {
        s[i] = tolower((unsigned char)s[i]);
    }
}

int answer_contains_required_terms() {
    FILE *fp = fopen("answer.txt", "r");
    if (!fp) return 0;

    char all[8192] = "";
    char line[1024];

    while (fgets(line, sizeof(line), fp)) {
        if (strlen(all) + strlen(line) < sizeof(all) - 1) {
            strcat(all, line);
        }
    }

    fclose(fp);
    to_lower_str(all);

    return strstr(all, "task 1") &&
           strstr(all, "task 2") &&
           strstr(all, "task 3") &&
           strstr(all, "alpha") &&
           strstr(all, "threshold") &&
           strstr(all, "evasion");
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int low_alpha_test =
        file_exists("summary_alpha_0p05.txt") &&
        file_has_current_nonce("summary_alpha_0p05.txt", nonce) &&
        log_has_step("test_evasion alpha=0.05");

    int evasion_candidate =
        file_exists("summary_alpha_0p30.txt") &&
        file_has_current_nonce("summary_alpha_0p30.txt", nonce) &&
        file_contains("summary_alpha_0p30.txt", "Evasion success: yes") &&
        log_has_step("test_evasion alpha=0.30");

    int high_alpha_detected =
        file_exists("summary_alpha_0p35.txt") &&
        file_has_current_nonce("summary_alpha_0p35.txt", nonce) &&
        file_contains("summary_alpha_0p35.txt", "Extracted OK: yes") &&
        file_contains("summary_alpha_0p35.txt", "Detected by threshold: yes") &&
        log_has_step("test_evasion alpha=0.35");

    if (low_alpha_test) {
        emit_hidden_token("low_alpha_test_completed");
    }

    if (evasion_candidate) {
        emit_hidden_token("evasion_candidate_found");
    }

    if (high_alpha_detected) {
        emit_hidden_token("high_alpha_detected");
    }

    if (answer_contains_required_terms()) {
        emit_hidden_token("answer_file_completed");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
