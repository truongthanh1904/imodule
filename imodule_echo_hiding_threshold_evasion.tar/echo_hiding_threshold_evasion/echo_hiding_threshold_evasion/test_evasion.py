#!/usr/bin/env python3
import argparse
import wave
import numpy as np
from lab_common import read_nonce, write_step

def normalize(x, peak=0.90):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def write_wav(path, rate, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm.tobytes())

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        value = 0
        for b in byte:
            value = (value << 1) | b
        chars.append(value)

    return bytes(chars).decode("utf-8", errors="replace")

def real_cepstrum(x):
    x = x - np.mean(x)
    x = x * np.hanning(len(x))

    nfft = 1
    while nfft < len(x):
        nfft *= 2

    spec = np.fft.rfft(x, n=nfft)
    log_mag = np.log(np.abs(spec) + 1e-12)
    return np.fft.irfft(log_mag, n=nfft)

def embed_echo(x, message, alpha, delay0, delay1):
    bits = text_to_bits(message)
    seg_len = len(x) // len(bits)

    if seg_len <= max(delay0, delay1) + 10:
        raise ValueError("Audio is too short for this message.")

    y = x.copy()

    for i, bit in enumerate(bits):
        start = i * seg_len
        end = start + seg_len
        delay = delay1 if bit else delay0
        y[start + delay:end] += alpha * x[start:end - delay]

    return normalize(y), seg_len

def extract_message(y, chars, delay0, delay1):
    bit_count = chars * 8
    seg_len = len(y) // bit_count
    bits = []

    for i in range(bit_count):
        start = i * seg_len
        end = start + seg_len
        seg = y[start:end]

        cep = real_cepstrum(seg)
        score0 = abs(cep[delay0])
        score1 = abs(cep[delay1])

        bits.append(1 if score1 > score0 else 0)

    return bits_to_text(bits)

def detect_score(y, delay_min, delay_max):
    cep = np.abs(real_cepstrum(y))
    region = cep[delay_min:delay_max + 1]
    median = np.median(region) + 1e-12

    peak_index = int(np.argmax(region))
    peak_delay = delay_min + peak_index
    peak_score = float(region[peak_index] / median)

    return peak_score, peak_delay

def alpha_tag(alpha):
    return f"{alpha:.2f}".replace(".", "p")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--alpha", type=float, required=True)
    p.add_argument("--threshold", type=float, default=9.0)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    p.add_argument("--delay-min", type=int, default=45)
    p.add_argument("--delay-max", type=int, default=85)
    args = p.parse_args()

    nonce = read_nonce()

    with open("message.txt", "r", encoding="utf-8") as f:
        message = f.read().strip()

    rate, cover = read_wav("cover.wav")

    tag = alpha_tag(args.alpha)
    stego_file = f"stego_alpha_{tag}.wav"
    summary_file = f"summary_alpha_{tag}.txt"

    stego, seg_len = embed_echo(
        cover,
        message,
        args.alpha,
        args.delay0,
        args.delay1
    )

    write_wav(stego_file, rate, stego)

    extracted = extract_message(
        stego,
        len(message),
        args.delay0,
        args.delay1
    )

    score, peak_delay = detect_score(
        stego,
        args.delay_min,
        args.delay_max
    )

    extracted_ok = extracted == message
    detected = score >= args.threshold
    evasion_success = extracted_ok and not detected

    with open(summary_file, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Alpha: {args.alpha:.2f}\n")
        f.write(f"Threshold: {args.threshold:.2f}\n")
        f.write(f"Stego file: {stego_file}\n")
        f.write(f"Segment length: {seg_len}\n")
        f.write(f"Extracted text: {extracted}\n")
        f.write(f"Extracted OK: {'yes' if extracted_ok else 'no'}\n")
        f.write(f"Detection score: {score:.4f}\n")
        f.write(f"Peak delay: {peak_delay}\n")
        f.write(f"Detected by threshold: {'yes' if detected else 'no'}\n")
        f.write(f"Evasion success: {'yes' if evasion_success else 'no'}\n")

    write_step(
        f"test_evasion alpha={args.alpha:.2f} threshold={args.threshold:.2f} "
        f"summary={summary_file} nonce={nonce} "
        f"extracted_ok={'yes' if extracted_ok else 'no'} "
        f"detected={'yes' if detected else 'no'} "
        f"evasion={'yes' if evasion_success else 'no'}"
    )

    print("Evasion test completed.")
    print(f"Alpha: {args.alpha:.2f}")
    print(f"Summary: {summary_file}")
    print(f"Extracted OK: {'yes' if extracted_ok else 'no'}")
    print(f"Detected by threshold: {'yes' if detected else 'no'}")
    print(f"Evasion success: {'yes' if evasion_success else 'no'}")

if __name__ == "__main__":
    main()
