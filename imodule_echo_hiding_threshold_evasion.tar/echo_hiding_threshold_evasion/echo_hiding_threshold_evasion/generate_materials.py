#!/usr/bin/env python3
import wave
import numpy as np

RATE = 16000
DURATION = 8.0

def normalize(x, peak=0.85):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())

def main():
    rng = np.random.default_rng(3030)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    x = (
        0.40 * np.sin(2 * np.pi * 440 * t) +
        0.25 * np.sin(2 * np.pi * 880 * t) +
        0.12 * np.sin(2 * np.pi * 1320 * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.3 * t)
    x = x * envelope
    x = x + 0.03 * rng.standard_normal(n)

    write_wav("cover.wav", x)

    with open("message.txt", "w", encoding="utf-8") as f:
        f.write("ECHO_EVASION")

    print("Generated cover.wav and message.txt")

if __name__ == "__main__":
    main()
