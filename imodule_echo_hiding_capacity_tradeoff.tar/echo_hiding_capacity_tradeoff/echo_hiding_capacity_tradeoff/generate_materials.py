#!/usr/bin/env python3
import wave
import numpy as np

RATE = 16000
DURATION = 8.0

def normalize(x, peak=0.85):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())

def main():
    rng = np.random.default_rng(4040)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    x = (
        0.40 * np.sin(2 * np.pi * 440 * t) +
        0.25 * np.sin(2 * np.pi * 880 * t) +
        0.12 * np.sin(2 * np.pi * 1320 * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.1 * t)
    x = x * envelope
    x = x + 0.025 * rng.standard_normal(n)

    write_wav("cover.wav", x)

    payloads = {
        "payload_short.txt": "ECHO",
        "payload_medium.txt": "ECHO_CAPACITY",
        "payload_long.txt": "ECHO_CAPACITY_LIMIT_TEST_MESSAGE_LONG"
    }

    for name, text in payloads.items():
        with open(name, "w", encoding="utf-8") as f:
            f.write(text)

    print("Generated cover.wav and payload files.")

if __name__ == "__main__":
    main()
