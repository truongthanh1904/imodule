#!/usr/bin/env python3
import argparse
import wave
import numpy as np
from lab_common import read_nonce, write_step

RATE = 16000

def normalize(x, peak=0.90):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def write_wav(path, rate, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm.tobytes())

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        value = 0
        for b in byte:
            value = (value << 1) | b
        chars.append(value)

    return bytes(chars).decode("utf-8", errors="replace")

def real_cepstrum(x):
    x = x - np.mean(x)
    x = x * np.hanning(len(x))

    nfft = 1
    while nfft < len(x):
        nfft *= 2

    spec = np.fft.rfft(x, n=nfft)
    log_mag = np.log(np.abs(spec) + 1e-12)
    return np.fft.irfft(log_mag, n=nfft)

def embed_echo(x, message, alpha, delay0, delay1):
    bits = text_to_bits(message)
    seg_len = len(x) // len(bits)

    if seg_len <= max(delay0, delay1) + 10:
        raise ValueError("Audio is too short for this payload.")

    y = x.copy()

    for i, bit in enumerate(bits):
        start = i * seg_len
        end = start + seg_len
        delay = delay1 if bit else delay0
        y[start + delay:end] += alpha * x[start:end - delay]

    return normalize(y), seg_len, len(bits)

def extract_message(y, chars, delay0, delay1):
    bit_count = chars * 8
    seg_len = len(y) // bit_count
    bits = []

    for i in range(bit_count):
        start = i * seg_len
        end = start + seg_len
        seg = y[start:end]

        cep = real_cepstrum(seg)
        s0 = abs(cep[delay0])
        s1 = abs(cep[delay1])

        bits.append(1 if s1 > s0 else 0)

    return bits_to_text(bits)

def snr_db(reference, test):
    noise = test - reference
    sp = np.mean(reference ** 2)
    npow = np.mean(noise ** 2) + 1e-12
    return 10 * np.log10(sp / npow)

def risk_level(seg_len):
    if seg_len >= 2500:
        return "low"
    if seg_len >= 900:
        return "medium"
    return "high"

def payload_file(level):
    if level == "short":
        return "payload_short.txt"
    if level == "medium":
        return "payload_medium.txt"
    return "payload_long.txt"

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--level", required=True, choices=["short", "medium", "long"])
    p.add_argument("--alpha", type=float, default=0.35)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    args = p.parse_args()

    nonce = read_nonce()
    payload_path = payload_file(args.level)

    rate, cover = read_wav("cover.wav")

    with open(payload_path, "r", encoding="utf-8") as f:
        message = f.read().strip()

    stego, seg_len, bit_count = embed_echo(
        cover,
        message,
        args.alpha,
        args.delay0,
        args.delay1
    )

    stego_file = f"stego_{args.level}.wav"
    summary_file = f"summary_{args.level}.txt"

    write_wav(stego_file, rate, stego)

    extracted = extract_message(
        stego,
        len(message),
        args.delay0,
        args.delay1
    )

    extracted_ok = extracted == message
    duration = len(cover) / rate
    capacity_bps = bit_count / duration
    quality_snr = snr_db(cover, stego)
    risk = risk_level(seg_len)
    reliable = extracted_ok and risk != "high"

    with open(summary_file, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Level: {args.level}\n")
        f.write(f"Payload file: {payload_path}\n")
        f.write(f"Payload text: {message}\n")
        f.write(f"Payload characters: {len(message)}\n")
        f.write(f"Payload bits: {bit_count}\n")
        f.write(f"Capacity bps: {capacity_bps:.2f}\n")
        f.write(f"Segment length: {seg_len}\n")
        f.write(f"Quality SNR dB: {quality_snr:.2f}\n")
        f.write(f"Extracted text: {extracted}\n")
        f.write(f"Extracted OK: {'yes' if extracted_ok else 'no'}\n")
        f.write(f"Capacity risk: {risk}\n")
        f.write(f"Reliable tradeoff: {'yes' if reliable else 'no'}\n")

    write_step(
        f"test_capacity level={args.level} summary={summary_file} "
        f"nonce={nonce} capacity_bps={capacity_bps:.2f} "
        f"risk={risk} reliable={'yes' if reliable else 'no'}"
    )

    print("Capacity test completed.")
    print(f"Level: {args.level}")
    print(f"Summary: {summary_file}")
    print(f"Capacity bps: {capacity_bps:.2f}")
    print(f"Capacity risk: {risk}")
    print(f"Reliable tradeoff: {'yes' if reliable else 'no'}")

if __name__ == "__main__":
    main()
