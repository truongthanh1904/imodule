#include <stdio.h>
#include <string.h>
#include <ctype.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_current_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void to_lower_str(char *s) {
    for (int i = 0; s[i]; i++) {
        s[i] = tolower((unsigned char)s[i]);
    }
}

int answer_contains_required_terms() {
    FILE *fp = fopen("answer.txt", "r");
    if (!fp) return 0;

    char all[8192] = "";
    char line[1024];

    while (fgets(line, sizeof(line), fp)) {
        if (strlen(all) + strlen(line) < sizeof(all) - 1) {
            strcat(all, line);
        }
    }

    fclose(fp);
    to_lower_str(all);

    return strstr(all, "task 1") &&
           strstr(all, "task 2") &&
           strstr(all, "task 3") &&
           strstr(all, "capacity") &&
           strstr(all, "snr") &&
           strstr(all, "segment") &&
           strstr(all, "tradeoff");
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int baseline_capacity =
        file_exists("summary_short.txt") &&
        file_has_current_nonce("summary_short.txt", nonce) &&
        file_contains("summary_short.txt", "Reliable tradeoff: yes") &&
        log_has_step("test_capacity level=short");

    int medium_capacity =
        file_exists("summary_medium.txt") &&
        file_has_current_nonce("summary_medium.txt", nonce) &&
        file_contains("summary_medium.txt", "Reliable tradeoff: yes") &&
        log_has_step("test_capacity level=medium");

    int high_capacity_limit =
        file_exists("summary_long.txt") &&
        file_has_current_nonce("summary_long.txt", nonce) &&
        file_contains("summary_long.txt", "Capacity risk: high") &&
        log_has_step("test_capacity level=long");

    if (baseline_capacity) {
        emit_hidden_token("baseline_capacity_completed");
    }

    if (medium_capacity) {
        emit_hidden_token("medium_capacity_completed");
    }

    if (high_capacity_limit) {
        emit_hidden_token("high_capacity_limit_observed");
    }

    if (answer_contains_required_terms()) {
        emit_hidden_token("answer_file_completed");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
