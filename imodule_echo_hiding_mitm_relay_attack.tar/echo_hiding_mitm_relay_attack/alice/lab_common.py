#!/usr/bin/env python3
import os
import hashlib
import hmac

def read_nonce():
    try:
        with open(".lab_nonce", "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "missing_nonce"

def write_step(line):
    try:
        os.makedirs(".local", exist_ok=True)
        with open(".local/lab_steps.log", "a", encoding="utf-8") as log:
            log.write(line + "\n")
    except Exception:
        pass

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()

def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def key_fingerprint(key):
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]

def make_hmac(auth_key, stego_hash, message_hash, key_fp, message_length):
    data = f"{stego_hash}|{message_hash}|{key_fp}|{message_length}"
    return hmac.new(auth_key.encode("utf-8"), data.encode("utf-8"), hashlib.sha256).hexdigest()
