#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_file, sha256_text, key_fingerprint, make_hmac

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-s", "--stego", default="stego_valid.wav")
    p.add_argument("-m", "--message", default="secret.txt")
    p.add_argument("-o", "--output", default="manifest.txt")
    p.add_argument("--echo-key", required=True)
    p.add_argument("--auth-key", required=True)
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.message, "r", encoding="utf-8") as f:
        message = f.read().strip()

    stego_hash = sha256_file(args.stego)
    message_hash = sha256_text(message)
    key_fp = key_fingerprint(args.echo_key)
    message_length = len(message)
    mac = make_hmac(args.auth_key, stego_hash, message_hash, key_fp, message_length)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Stego file: {args.stego}\n")
        f.write(f"Stego hash: {stego_hash}\n")
        f.write(f"Message hash: {message_hash}\n")
        f.write(f"Message length: {message_length}\n")
        f.write(f"Echo key fingerprint: {key_fp}\n")
        f.write(f"HMAC: {mac}\n")

    with open("alice_package_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Manifest: {args.output}\n")
        f.write(f"Stego hash: {stego_hash}\n")
        f.write(f"Message hash: {message_hash}\n")
        f.write(f"Echo key fingerprint: {key_fp}\n")
        f.write("Package created: yes\n")

    write_step(
        f"make_manifest stego={args.stego} manifest={args.output} "
        f"nonce={nonce} package_created=yes"
    )

    print("Manifest created.")
    print("Output: manifest.txt")
    print("Report: alice_package_report.txt")

if __name__ == "__main__":
    main()
