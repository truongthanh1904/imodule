#!/bin/bash
set -e

RELAY_HOST="${1}"
RELAY_USER="ubuntu"
RELAY_PASS="password123"

if [ -z "$RELAY_HOST" ]; then
    echo "Usage: ./send_to_relay.sh <IP_MALLORY>"
    exit 1
fi

required_files="stego_valid.wav manifest.txt alice_package_report.txt .lab_nonce"

for f in $required_files; do
    if [ ! -f "$f" ]; then
        echo "Missing required file: $f"
        exit 1
    fi
done

cp .lab_nonce alice_session_nonce.txt

cat > relay_send_report.txt <<EOF
Run nonce: $(cat .lab_nonce)
Transfer method: scp
Destination role: mallory relay
Transferred stego: yes
Transferred manifest: yes
Transferred package report: yes
Transferred alice nonce: yes
Relay transfer completed: yes
EOF

sshpass -p "$RELAY_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    stego_valid.wav "$RELAY_USER@$RELAY_HOST:/home/ubuntu/intercepted_stego.wav"

sshpass -p "$RELAY_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    manifest.txt "$RELAY_USER@$RELAY_HOST:/home/ubuntu/intercepted_manifest.txt"

sshpass -p "$RELAY_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    alice_package_report.txt "$RELAY_USER@$RELAY_HOST:/home/ubuntu/intercepted_alice_package_report.txt"

sshpass -p "$RELAY_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    alice_session_nonce.txt "$RELAY_USER@$RELAY_HOST:/home/ubuntu/received_alice_nonce.txt"

sshpass -p "$RELAY_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    relay_send_report.txt "$RELAY_USER@$RELAY_HOST:/home/ubuntu/relay_receive_report.txt"

echo "Package sent to relay."
