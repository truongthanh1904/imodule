#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

sudo service ssh start >/tmp/ssh_start.log 2>&1 || service ssh start >/tmp/ssh_start.log 2>&1

if [ ! -f cover.wav ] || [ ! -f secret.txt ]; then
    python3 generate_materials.py > /tmp/generate_materials.log 2>&1
fi

chmod +x generate_materials.py 2>/dev/null
chmod +x alice_embed.py 2>/dev/null
chmod +x make_manifest.py 2>/dev/null
chmod +x send_to_relay.sh 2>/dev/null
chmod +x send_to_bob_direct.sh 2>/dev/null
