#!/bin/bash
set -e

BOB_HOST="${1}"
BOB_USER="ubuntu"
BOB_PASS="password123"

if [ -z "$BOB_HOST" ]; then
    echo "Usage: ./send_to_bob_direct.sh <IP_BOB>"
    exit 1
fi

required_files="stego_valid.wav manifest.txt alice_package_report.txt .lab_nonce"

for f in $required_files; do
    if [ ! -f "$f" ]; then
        echo "Missing required file: $f"
        exit 1
    fi
done

cp .lab_nonce trusted_alice_nonce.txt

cat > trusted_redelivery_report.txt <<EOF
Run nonce: $(cat .lab_nonce)
Transfer method: scp
Destination role: bob
Transferred trusted stego: yes
Transferred trusted manifest: yes
Trusted redelivery: yes
EOF

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    stego_valid.wav "$BOB_USER@$BOB_HOST:/home/ubuntu/trusted_stego.wav"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    manifest.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/trusted_manifest.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    alice_package_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/trusted_alice_package_report.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    trusted_alice_nonce.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/trusted_alice_nonce.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    trusted_redelivery_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/trusted_redelivery_report.txt"

echo "Trusted package sent directly to Bob."
