#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_file, sha256_text, key_fingerprint
from echo_keyed import generate_cover, write_wav, embed_keyed

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--key", required=True)
    p.add_argument("--input", default="intercepted_stego.wav")
    p.add_argument("--manifest", default="intercepted_manifest.txt")
    p.add_argument("--output", default="stego_forged.wav")
    p.add_argument("--fake-message", default="fake_message.txt")
    args = p.parse_args()

    nonce = read_nonce()

    fake_text = "Hi I am Mallory"
    with open(args.fake_message, "w", encoding="utf-8") as f:
        f.write(fake_text)

    cover = generate_cover()
    forged, seg_len, bit_count = embed_keyed(cover, fake_text, args.key)
    write_wav(args.output, 16000, forged)

    original_hash = sha256_file(args.input)
    forged_hash = sha256_file(args.output)
    hash_changed = original_hash != forged_hash

    with open("forge_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Original stego: {args.input}\n")
        f.write(f"Forged stego: {args.output}\n")
        f.write(f"Fake message: {fake_text}\n")
        f.write(f"Fake message hash: {sha256_text(fake_text)}\n")
        f.write(f"Key fingerprint used by Mallory: {key_fingerprint(args.key)}\n")
        f.write(f"Original hash: {original_hash}\n")
        f.write(f"Forged hash: {forged_hash}\n")
        f.write(f"Hash changed: {'yes' if hash_changed else 'no'}\n")
        f.write("Forgery performed: yes\n")

    write_step(
        f"mallory_forge input={args.input} output={args.output} "
        f"nonce={nonce} hash_changed={'yes' if hash_changed else 'no'}"
    )

    print("Mallory forged a new stego file.")
    print("Fake message: Hi I am Mallory")
    print("Output: stego_forged.wav")
    print("Report: forge_report.txt")

if __name__ == "__main__":
    main()
