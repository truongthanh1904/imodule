#!/usr/bin/env python3
import wave
import hashlib
import numpy as np

def normalize(x, peak=0.90):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, rate, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes(pcm.tobytes())

def text_to_bits(text):
    bits = []
    for b in text.encode("utf-8"):
        bits.extend([(b >> i) & 1 for i in range(7, -1, -1)])
    return bits

def seed_from_key(key):
    digest = hashlib.sha256(key.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")

def keyed_permutation(key, count):
    rng = np.random.default_rng(seed_from_key(key))
    return rng.permutation(count)

def generate_cover(rate=16000, duration=8.0):
    rng = np.random.default_rng(8080)
    n = int(rate * duration)
    t = np.arange(n) / rate

    x = (
        0.38 * np.sin(2 * np.pi * 440 * t) +
        0.24 * np.sin(2 * np.pi * 880 * t) +
        0.12 * np.sin(2 * np.pi * 1760 * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.4 * t)
    x = x * envelope
    x = x + 0.025 * rng.standard_normal(n)

    return normalize(x)

def embed_keyed(audio, message, key, alpha=0.42, delay0=50, delay1=75):
    bits = text_to_bits(message)
    bit_count = len(bits)
    seg_len = len(audio) // bit_count

    if seg_len <= max(delay0, delay1) + 10:
        raise ValueError("Audio is too short for this message.")

    order = keyed_permutation(key, bit_count)
    y = audio.copy()

    for bit_index, seg_index in enumerate(order):
        bit = bits[bit_index]
        start = int(seg_index) * seg_len
        end = start + seg_len
        delay = delay1 if bit else delay0
        y[start + delay:end] += alpha * audio[start:end-delay]

    return normalize(y), seg_len, bit_count
