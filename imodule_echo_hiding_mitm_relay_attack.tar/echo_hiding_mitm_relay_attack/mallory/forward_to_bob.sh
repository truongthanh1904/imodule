#!/bin/bash
set -e

BOB_HOST="${1}"
BOB_USER="ubuntu"
BOB_PASS="password123"

if [ -z "$BOB_HOST" ]; then
    echo "Usage: ./forward_to_bob.sh <IP_BOB>"
    exit 1
fi

required_files="stego_forged.wav intercepted_manifest.txt forge_report.txt received_alice_nonce.txt relay_receive_report.txt intercepted_alice_package_report.txt .lab_nonce"

for f in $required_files; do
    if [ ! -f "$f" ]; then
        echo "Missing required file: $f"
        exit 1
    fi
done

cp .lab_nonce mallory_session_nonce.txt

cat > forward_report.txt <<EOF
Run nonce: $(cat .lab_nonce)
Transfer method: scp
Source role: mallory relay
Destination role: bob
Forwarded forged stego: yes
Forwarded original manifest: yes
Forwarded forge report: yes
Forged file forwarded: yes
EOF

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    stego_forged.wav "$BOB_USER@$BOB_HOST:/home/ubuntu/received_stego.wav"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    intercepted_manifest.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_manifest.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    forge_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_forge_report.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    mallory_session_nonce.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_mallory_nonce.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    received_alice_nonce.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_alice_nonce.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    relay_receive_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/relay_receive_report.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    intercepted_alice_package_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_alice_package_report.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    forward_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/forward_report.txt"

echo "Forged package forwarded to Bob."
