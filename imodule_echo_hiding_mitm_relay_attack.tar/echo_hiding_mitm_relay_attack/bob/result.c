#include <stdio.h>
#include <string.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[2048];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_first_line(const char *filename, char *buf, int size) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[2048];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char bob_nonce[256] = "";
    char alice_nonce[256] = "";
    char trusted_alice_nonce[256] = "";
    char mallory_nonce[256] = "";

    if (!read_first_line(".lab_nonce", bob_nonce, sizeof(bob_nonce))) {
        emit_hidden_token("missing_bob_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int has_alice_nonce = read_first_line("received_alice_nonce.txt", alice_nonce, sizeof(alice_nonce));
    int has_trusted_alice_nonce = read_first_line("trusted_alice_nonce.txt", trusted_alice_nonce, sizeof(trusted_alice_nonce));
    int has_mallory_nonce = read_first_line("received_mallory_nonce.txt", mallory_nonce, sizeof(mallory_nonce));

    int alice_package_created =
        has_alice_nonce &&
        file_exists("received_alice_package_report.txt") &&
        file_has_nonce("received_alice_package_report.txt", alice_nonce) &&
        file_contains("received_alice_package_report.txt", "Package created: yes");

    int relay_received_package =
        has_alice_nonce &&
        file_exists("relay_receive_report.txt") &&
        file_has_nonce("relay_receive_report.txt", alice_nonce) &&
        file_contains("relay_receive_report.txt", "Relay transfer completed: yes") &&
        file_exists("received_alice_package_report.txt");

    int forgery_performed =
        has_mallory_nonce &&
        file_exists("received_forge_report.txt") &&
        file_has_nonce("received_forge_report.txt", mallory_nonce) &&
        file_contains("received_forge_report.txt", "Fake message: Hi I am Mallory") &&
        file_contains("received_forge_report.txt", "Hash changed: yes") &&
        file_contains("received_forge_report.txt", "Forgery performed: yes");

    int forged_file_forwarded =
        has_mallory_nonce &&
        file_exists("received_stego.wav") &&
        file_exists("received_manifest.txt") &&
        file_exists("forward_report.txt") &&
        file_has_nonce("forward_report.txt", mallory_nonce) &&
        file_contains("forward_report.txt", "Forged file forwarded: yes");

    int bob_forgery_detected =
        file_exists("forgery_verify_report.txt") &&
        file_has_nonce("forgery_verify_report.txt", bob_nonce) &&
        file_contains("forgery_verify_report.txt", "Mode: forged") &&
        file_contains("forgery_verify_report.txt", "Hash match: no") &&
        file_contains("forgery_verify_report.txt", "HMAC valid: no") &&
        file_contains("forgery_verify_report.txt", "Forgery detected: yes") &&
        file_contains("forgery_verify_report.txt", "Reject extraction: yes") &&
        log_has_step("verify_manifest mode=forged");

    int trusted_redelivery =
        has_trusted_alice_nonce &&
        file_exists("trusted_stego.wav") &&
        file_exists("trusted_manifest.txt") &&
        file_exists("trusted_redelivery_report.txt") &&
        file_has_nonce("trusted_redelivery_report.txt", trusted_alice_nonce) &&
        file_contains("trusted_redelivery_report.txt", "Trusted redelivery: yes");

    int trusted_package_verified =
        file_exists("trusted_verify_report.txt") &&
        file_has_nonce("trusted_verify_report.txt", bob_nonce) &&
        file_contains("trusted_verify_report.txt", "Mode: trusted") &&
        file_contains("trusted_verify_report.txt", "Hash match: yes") &&
        file_contains("trusted_verify_report.txt", "HMAC valid: yes") &&
        file_contains("trusted_verify_report.txt", "Trusted delivery verified: yes") &&
        log_has_step("verify_manifest mode=trusted");

    int bob_final_extraction =
        file_exists("bob_message.txt") &&
        file_exists("bob_extract_report.txt") &&
        file_has_nonce("bob_extract_report.txt", bob_nonce) &&
        file_contains("bob_extract_report.txt", "Extracted text: Hi I am Alice") &&
        file_contains("bob_extract_report.txt", "Extracted OK: yes") &&
        file_contains("bob_extract_report.txt", "Final extraction completed: yes") &&
        log_has_step("bob_extract input=trusted_stego.wav");

    if (alice_package_created) {
        emit_hidden_token("alice_package_created");
    }

    if (relay_received_package) {
        emit_hidden_token("relay_received_package");
    }

    if (forgery_performed) {
        emit_hidden_token("forgery_performed");
    }

    if (forged_file_forwarded) {
        emit_hidden_token("forged_file_forwarded");
    }

    if (bob_forgery_detected) {
        emit_hidden_token("bob_forgery_detected");
    }

    if (trusted_redelivery) {
        emit_hidden_token("trusted_redelivery");
    }

    if (trusted_package_verified) {
        emit_hidden_token("trusted_package_verified");
    }

    if (bob_final_extraction) {
        emit_hidden_token("bob_final_extraction");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
