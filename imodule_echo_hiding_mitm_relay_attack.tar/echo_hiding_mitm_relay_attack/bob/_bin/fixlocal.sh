#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

sudo service ssh start >/tmp/ssh_start.log 2>&1 || service ssh start >/tmp/ssh_start.log 2>&1

chmod +x verify_manifest.py 2>/dev/null
chmod +x bob_extract.py 2>/dev/null
