#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_file, key_fingerprint, make_hmac

def parse_manifest(path):
    data = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if ":" in line:
                k, v = line.split(":", 1)
                data[k.strip()] = v.strip()
    return data

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--key", required=True)
    p.add_argument("--auth-key", required=True)
    p.add_argument("--mode", choices=["forged", "trusted"], required=True)
    args = p.parse_args()

    nonce = read_nonce()

    if args.mode == "forged":
        stego_file = "received_stego.wav"
        manifest_file = "received_manifest.txt"
        output = "forgery_verify_report.txt"
    else:
        stego_file = "trusted_stego.wav"
        manifest_file = "trusted_manifest.txt"
        output = "trusted_verify_report.txt"

    manifest = parse_manifest(manifest_file)

    expected_stego_hash = manifest.get("Stego hash", "")
    expected_message_hash = manifest.get("Message hash", "")
    expected_key_fp = manifest.get("Echo key fingerprint", "")
    expected_len = manifest.get("Message length", "")
    expected_hmac = manifest.get("HMAC", "")

    actual_stego_hash = sha256_file(stego_file)
    actual_key_fp = key_fingerprint(args.key)

    calculated_hmac = make_hmac(
        args.auth_key,
        actual_stego_hash,
        expected_message_hash,
        actual_key_fp,
        expected_len
    )

    hash_match = actual_stego_hash == expected_stego_hash
    key_match = actual_key_fp == expected_key_fp
    hmac_valid = calculated_hmac == expected_hmac
    forgery_detected = not (hash_match and key_match and hmac_valid)

    trusted_verified = (
        args.mode == "trusted" and
        hash_match and
        key_match and
        hmac_valid
    )

    reject_extraction = args.mode == "forged" and forgery_detected

    with open(output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Mode: {args.mode}\n")
        f.write(f"Stego file: {stego_file}\n")
        f.write(f"Manifest file: {manifest_file}\n")
        f.write(f"Expected stego hash: {expected_stego_hash}\n")
        f.write(f"Actual stego hash: {actual_stego_hash}\n")
        f.write(f"Hash match: {'yes' if hash_match else 'no'}\n")
        f.write(f"Key fingerprint match: {'yes' if key_match else 'no'}\n")
        f.write(f"HMAC valid: {'yes' if hmac_valid else 'no'}\n")
        f.write(f"Forgery detected: {'yes' if forgery_detected else 'no'}\n")
        f.write(f"Reject extraction: {'yes' if reject_extraction else 'no'}\n")
        f.write(f"Trusted delivery verified: {'yes' if trusted_verified else 'no'}\n")

    write_step(
        f"verify_manifest mode={args.mode} output={output} nonce={nonce} "
        f"hash_match={'yes' if hash_match else 'no'} "
        f"hmac_valid={'yes' if hmac_valid else 'no'}"
    )

    print("Manifest verification completed.")
    print(f"Mode: {args.mode}")
    print(f"Output: {output}")
    print(f"Forgery detected: {'yes' if forgery_detected else 'no'}")
    print(f"Trusted delivery verified: {'yes' if trusted_verified else 'no'}")

if __name__ == "__main__":
    main()
