#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_text
from echo_keyed import read_wav, extract_keyed

def parse_manifest(path):
    data = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if ":" in line:
                k, v = line.split(":", 1)
                data[k.strip()] = v.strip()
    return data

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--key", required=True)
    p.add_argument("--input", default="trusted_stego.wav")
    p.add_argument("--manifest", default="trusted_manifest.txt")
    p.add_argument("--output", default="bob_message.txt")
    p.add_argument("--report", default="bob_extract_report.txt")
    args = p.parse_args()

    nonce = read_nonce()

    manifest = parse_manifest(args.manifest)
    expected_hash = manifest.get("Message hash", "")
    chars = int(manifest.get("Message length", "0"))

    rate, audio = read_wav(args.input)
    extracted = extract_keyed(audio, args.key, chars)
    actual_hash = sha256_text(extracted)

    extracted_ok = actual_hash == expected_hash

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(extracted + "\n")

    with open(args.report, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Manifest: {args.manifest}\n")
        f.write(f"Extracted text: {extracted}\n")
        f.write(f"Expected message hash: {expected_hash}\n")
        f.write(f"Actual message hash: {actual_hash}\n")
        f.write(f"Extracted OK: {'yes' if extracted_ok else 'no'}\n")
        f.write(f"Final extraction completed: {'yes' if extracted_ok else 'no'}\n")

    write_step(
        f"bob_extract input={args.input} output={args.output} "
        f"nonce={nonce} extracted_ok={'yes' if extracted_ok else 'no'}"
    )

    print("Bob extraction completed.")
    print(f"Extracted text: {extracted}")
    print(f"Extracted OK: {'yes' if extracted_ok else 'no'}")

if __name__ == "__main__":
    main()
