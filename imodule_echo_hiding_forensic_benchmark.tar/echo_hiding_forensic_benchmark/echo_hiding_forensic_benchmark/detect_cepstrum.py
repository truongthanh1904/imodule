#!/usr/bin/env python3
import argparse
import os
import numpy as np
from lab_common import read_nonce, write_step
from echo_tools import read_wav, real_cepstrum

def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--threshold", type=float, default=6.0)
    p.add_argument("--delay-min", type=int, default=45)
    p.add_argument("--delay-max", type=int, default=85)
    args = p.parse_args()

    nonce = read_nonce()
    rate, audio = read_wav(args.input)

    cep = np.abs(real_cepstrum(audio))
    region = cep[args.delay_min:args.delay_max + 1]
    median = np.median(region) + 1e-12
    peak_idx = int(np.argmax(region))
    peak_delay = args.delay_min + peak_idx
    score = float(region[peak_idx] / median)

    prediction = "stego" if score >= args.threshold else "clean"
    filename = os.path.basename(args.input)

    print(f"Run nonce: {nonce}")
    print("Detector: cepstrum")
    print(f"File: {filename}")
    print(f"Peak delay: {peak_delay}")
    print(f"Score: {score:.4f}")
    print(f"Prediction: {prediction}")
    print(f"RESULT,cepstrum,{filename},{prediction},{score:.4f}")

    write_step(f"detect_cepstrum file={filename} prediction={prediction} nonce={nonce}")

if __name__ == "__main__":
    main()
