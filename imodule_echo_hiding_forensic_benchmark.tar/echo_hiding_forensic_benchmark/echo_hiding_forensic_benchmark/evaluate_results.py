#!/usr/bin/env python3
import argparse
import csv
import os
from lab_common import read_nonce, write_step

DETECTORS = [
    "cepstrum",
    "autocorr",
    "delay_pair",
    "extraction_confidence"
]

def read_labels(path):
    labels = {}
    messages = {}

    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            labels[row["filename"]] = row["label"]
            messages[row["filename"]] = row.get("message", "")

    return labels, messages

def parse_result_line(line):
    # RESULT,detector,filename,prediction,score
    parts = line.strip().split(",")
    if len(parts) != 5:
        return None
    if parts[0] != "RESULT":
        return None

    return {
        "detector": parts[1],
        "filename": parts[2],
        "prediction": parts[3],
        "score": parts[4]
    }

def read_detector_results(report_path):
    results = []

    if not os.path.exists(report_path):
        return results

    with open(report_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            parsed = parse_result_line(line)
            if parsed:
                results.append(parsed)

    return results

def confusion_for_detector(rows, labels):
    tp = tn = fp = fn = 0

    for row in rows:
        filename = row["filename"]
        pred = row["prediction"]
        truth = labels.get(filename)

        if truth == "stego" and pred == "stego":
            tp += 1
        elif truth == "clean" and pred == "clean":
            tn += 1
        elif truth == "clean" and pred == "stego":
            fp += 1
        elif truth == "stego" and pred == "clean":
            fn += 1

    total = tp + tn + fp + fn
    acc = (tp + tn) / total if total else 0.0

    return tp, tn, fp, fn, acc

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--labels", default="labels.csv")
    p.add_argument("--reports", default="reports")
    p.add_argument("--output", default="final_benchmark.csv")
    p.add_argument("--summary", default="confusion_report.txt")
    args = p.parse_args()

    nonce = read_nonce()
    labels, messages = read_labels(args.labels)

    all_rows = []
    detector_rows = {d: [] for d in DETECTORS}

    for detector in DETECTORS:
        report_path = os.path.join(args.reports, f"{detector}_results.txt")
        rows = read_detector_results(report_path)

        for row in rows:
            filename = row["filename"]
            row["truth"] = labels.get(filename, "unknown")
            row["message"] = messages.get(filename, "")
            all_rows.append(row)
            detector_rows[detector].append(row)

    with open(args.output, "w", encoding="utf-8", newline="") as f:
        fieldnames = ["detector", "filename", "truth", "prediction", "score", "message"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for row in all_rows:
            writer.writerow({
                "detector": row["detector"],
                "filename": row["filename"],
                "truth": row["truth"],
                "prediction": row["prediction"],
                "score": row["score"],
                "message": row["message"]
            })

    summary_rows = []
    best_detector = ""
    best_acc = -1.0

    with open(args.summary, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write("Forensic benchmark summary\n")

        for detector in DETECTORS:
            tp, tn, fp, fn, acc = confusion_for_detector(detector_rows[detector], labels)
            summary_rows.append((detector, tp, tn, fp, fn, acc))

            if acc > best_acc:
                best_acc = acc
                best_detector = detector

            f.write("\n")
            f.write(f"Detector: {detector}\n")
            f.write(f"True Positive: {tp}\n")
            f.write(f"True Negative: {tn}\n")
            f.write(f"False Positive: {fp}\n")
            f.write(f"False Negative: {fn}\n")
            f.write(f"Accuracy: {acc:.4f}\n")

        f.write("\n")
        f.write(f"Best detector: {best_detector}\n")
        f.write(f"Benchmark completed: yes\n")

    write_step(
        f"evaluate_results labels={args.labels} reports={args.reports} "
        f"output={args.output} nonce={nonce} benchmark_completed=yes"
    )

    print("Benchmark evaluation completed.")
    print(f"Output: {args.output}")
    print(f"Summary: {args.summary}")
    print(f"Best detector: {best_detector}")

if __name__ == "__main__":
    main()
