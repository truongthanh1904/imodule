#!/usr/bin/env python3
import argparse
import os
import numpy as np
from lab_common import read_nonce, write_step
from echo_tools import read_wav

def norm_autocorr(x, max_lag):
    x = x - np.mean(x)
    denom = np.sum(x * x) + 1e-12
    scores = []
    for lag in range(max_lag + 1):
        if lag == 0:
            scores.append(1.0)
        else:
            scores.append(float(np.sum(x[lag:] * x[:-lag]) / denom))
    return np.array(scores)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--threshold", type=float, default=0.055)
    p.add_argument("--delay-min", type=int, default=45)
    p.add_argument("--delay-max", type=int, default=85)
    args = p.parse_args()

    nonce = read_nonce()
    rate, audio = read_wav(args.input)
    ac = np.abs(norm_autocorr(audio, args.delay_max))

    region = ac[args.delay_min:args.delay_max + 1]
    peak_idx = int(np.argmax(region))
    peak_delay = args.delay_min + peak_idx
    score = float(region[peak_idx])

    prediction = "stego" if score >= args.threshold else "clean"
    filename = os.path.basename(args.input)

    print(f"Run nonce: {nonce}")
    print("Detector: autocorr")
    print(f"File: {filename}")
    print(f"Peak delay: {peak_delay}")
    print(f"Score: {score:.4f}")
    print(f"Prediction: {prediction}")
    print(f"RESULT,autocorr,{filename},{prediction},{score:.4f}")

    write_step(f"detect_autocorr file={filename} prediction={prediction} nonce={nonce}")

if __name__ == "__main__":
    main()
