#!/usr/bin/env python3
import argparse
import os
from lab_common import read_nonce, write_step
from echo_tools import read_wav, extract_echo

def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--chars", type=int, default=8)
    args = p.parse_args()

    nonce = read_nonce()
    rate, audio = read_wav(args.input)
    msg = extract_echo(audio, chars=args.chars)
    filename = os.path.basename(args.input)

    print(f"Run nonce: {nonce}")
    print(f"File: {filename}")
    print(f"Extracted message: {msg}")
    print(f"EXTRACT,{filename},{msg}")

    write_step(f"extract_echo file={filename} message={msg} nonce={nonce}")

if __name__ == "__main__":
    main()
