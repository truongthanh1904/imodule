#!/usr/bin/env python3
import argparse
import os
import numpy as np
from lab_common import read_nonce, write_step
from echo_tools import read_wav, aggregate_segment_cepstrum

def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--chars", type=int, default=8)
    p.add_argument("--delay0", type=int, default=50)
    p.add_argument("--delay1", type=int, default=75)
    p.add_argument("--threshold", type=float, default=3.5)
    args = p.parse_args()

    nonce = read_nonce()
    rate, audio = read_wav(args.input)

    cep = aggregate_segment_cepstrum(audio, chars=args.chars)
    region = np.abs(cep[45:86])
    median = np.median(region) + 1e-12

    s0 = abs(cep[args.delay0]) / median
    s1 = abs(cep[args.delay1]) / median
    score = float((s0 + s1) / 2.0)

    prediction = "stego" if score >= args.threshold else "clean"
    filename = os.path.basename(args.input)

    print(f"Run nonce: {nonce}")
    print("Detector: delay_pair")
    print(f"File: {filename}")
    print(f"Delay0 score: {s0:.4f}")
    print(f"Delay1 score: {s1:.4f}")
    print(f"Score: {score:.4f}")
    print(f"Prediction: {prediction}")
    print(f"RESULT,delay_pair,{filename},{prediction},{score:.4f}")

    write_step(f"detect_delay_pair file={filename} prediction={prediction} nonce={nonce}")

if __name__ == "__main__":
    main()
