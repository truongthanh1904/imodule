#!/usr/bin/env python3
import os
from lab_common import read_nonce, write_step

def main():
    nonce = read_nonce()

    print(f"Run nonce: {nonce}")
    print("Dataset files:")
    for name in sorted(os.listdir("dataset")):
        if name.endswith(".wav"):
            path = os.path.join("dataset", name)
            size = os.path.getsize(path)
            print(f"- {name}: {size} bytes")

    print("\nlabels.csv:")
    with open("labels.csv", "r", encoding="utf-8") as f:
        print(f.read())

    write_step(f"review_dataset labels=labels.csv dataset=dataset nonce={nonce}")

if __name__ == "__main__":
    main()
