#!/usr/bin/env python3
import argparse
import os
from lab_common import read_nonce, write_step
from echo_tools import read_wav, extract_echo

def printable_ratio(s):
    if not s:
        return 0.0
    ok = 0
    allowed = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_ -"
    for ch in s:
        if ch in allowed:
            ok += 1
    return ok / len(s)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("--chars", type=int, default=8)
    p.add_argument("--threshold", type=float, default=0.75)
    args = p.parse_args()

    nonce = read_nonce()
    rate, audio = read_wav(args.input)

    extracted = extract_echo(audio, chars=args.chars)
    score = printable_ratio(extracted)
    prediction = "stego" if score >= args.threshold else "clean"
    filename = os.path.basename(args.input)

    print(f"Run nonce: {nonce}")
    print("Detector: extraction_confidence")
    print(f"File: {filename}")
    print(f"Extracted candidate: {extracted}")
    print(f"Score: {score:.4f}")
    print(f"Prediction: {prediction}")
    print(f"RESULT,extraction_confidence,{filename},{prediction},{score:.4f}")

    write_step(f"detect_extraction_confidence file={filename} prediction={prediction} nonce={nonce}")

if __name__ == "__main__":
    main()
