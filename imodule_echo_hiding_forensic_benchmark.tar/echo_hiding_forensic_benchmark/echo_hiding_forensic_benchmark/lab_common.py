#!/usr/bin/env python3
import os

def read_nonce():
    try:
        with open(".lab_nonce", "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "missing_nonce"

def write_step(line):
    try:
        os.makedirs(".local", exist_ok=True)
        with open(".local/lab_steps.log", "a", encoding="utf-8") as log:
            log.write(line + "\n")
    except Exception:
        pass
