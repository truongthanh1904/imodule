#!/usr/bin/env python3
import os
import numpy as np
from echo_tools import write_wav, normalize, embed_echo

RATE = 16000
DURATION = 8.0

def make_cover(seed, freq_shift=0.0):
    rng = np.random.default_rng(seed)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    x = (
        0.36 * np.sin(2 * np.pi * (440 + freq_shift) * t) +
        0.24 * np.sin(2 * np.pi * (880 + freq_shift) * t) +
        0.12 * np.sin(2 * np.pi * (1760 + freq_shift) * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.2 * t)
    x = x * envelope
    x = x + 0.025 * rng.standard_normal(n)

    return normalize(x, 0.85)

def main():
    os.makedirs("dataset", exist_ok=True)

    clean_specs = [
        ("clean_01.wav", 1111, 0.0),
        ("clean_02.wav", 2222, 10.0),
        ("clean_03.wav", 3333, 20.0),
    ]

    stego_specs = [
        ("stego_01.wav", 4444, 0.0, "HI_ALICE"),
        ("stego_02.wav", 5555, 10.0, "ECHO_LAB"),
        ("stego_03.wav", 6666, 20.0, "PTIT2026"),
    ]

    with open("labels.csv", "w", encoding="utf-8") as f:
        f.write("filename,label,message\n")

        for filename, seed, shift in clean_specs:
            cover = make_cover(seed, shift)
            write_wav(os.path.join("dataset", filename), RATE, cover)
            f.write(f"{filename},clean,\n")

        for filename, seed, shift, message in stego_specs:
            cover = make_cover(seed, shift)
            stego, seg_len, bit_count = embed_echo(cover, message)
            write_wav(os.path.join("dataset", filename), RATE, stego)
            f.write(f"{filename},stego,{message}\n")

    print("Generated dataset/ and labels.csv")

if __name__ == "__main__":
    main()
