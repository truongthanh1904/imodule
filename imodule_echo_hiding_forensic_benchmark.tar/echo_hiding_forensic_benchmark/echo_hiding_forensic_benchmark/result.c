#include <stdio.h>
#include <string.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[4096];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_nonce(char *buf, int size) {
    FILE *fp = fopen(".lab_nonce", "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_current_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[4096];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char nonce[256] = "";

    if (!read_nonce(nonce, sizeof(nonce))) {
        emit_hidden_token("missing_current_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int dataset_reviewed =
        file_exists("labels.csv") &&
        file_exists("dataset/clean_01.wav") &&
        file_exists("dataset/clean_02.wav") &&
        file_exists("dataset/clean_03.wav") &&
        file_exists("dataset/stego_01.wav") &&
        file_exists("dataset/stego_02.wav") &&
        file_exists("dataset/stego_03.wav") &&
        log_has_step("review_dataset labels=labels.csv");

    int detector_code_reviewed =
        log_has_step("review_code detector=cepstrum") &&
        log_has_step("review_code detector=autocorr") &&
        log_has_step("review_code detector=delay_pair") &&
        log_has_step("review_code detector=extraction_confidence");

    int cepstrum_analysis =
        file_exists("reports/cepstrum_results.txt") &&
        file_has_current_nonce("reports/cepstrum_results.txt", nonce) &&
        file_contains("reports/cepstrum_results.txt", "RESULT,cepstrum,clean_01.wav") &&
        file_contains("reports/cepstrum_results.txt", "RESULT,cepstrum,stego_03.wav") &&
        log_has_step("detect_cepstrum file=stego_03.wav");

    int autocorr_analysis =
        file_exists("reports/autocorr_results.txt") &&
        file_has_current_nonce("reports/autocorr_results.txt", nonce) &&
        file_contains("reports/autocorr_results.txt", "RESULT,autocorr,clean_01.wav") &&
        file_contains("reports/autocorr_results.txt", "RESULT,autocorr,stego_03.wav") &&
        log_has_step("detect_autocorr file=stego_03.wav");

    int delaypair_analysis =
        file_exists("reports/delay_pair_results.txt") &&
        file_has_current_nonce("reports/delay_pair_results.txt", nonce) &&
        file_contains("reports/delay_pair_results.txt", "RESULT,delay_pair,clean_01.wav") &&
        file_contains("reports/delay_pair_results.txt", "RESULT,delay_pair,stego_03.wav") &&
        log_has_step("detect_delay_pair file=stego_03.wav");

    int extraction_confidence_analysis =
        file_exists("reports/extraction_confidence_results.txt") &&
        file_has_current_nonce("reports/extraction_confidence_results.txt", nonce) &&
        file_contains("reports/extraction_confidence_results.txt", "RESULT,extraction_confidence,clean_01.wav") &&
        file_contains("reports/extraction_confidence_results.txt", "RESULT,extraction_confidence,stego_03.wav") &&
        log_has_step("detect_extraction_confidence file=stego_03.wav");

    int benchmark_report =
        file_exists("final_benchmark.csv") &&
        file_exists("confusion_report.txt") &&
        file_has_current_nonce("confusion_report.txt", nonce) &&
        file_contains("confusion_report.txt", "Best detector:") &&
        file_contains("confusion_report.txt", "Benchmark completed: yes") &&
        log_has_step("evaluate_results labels=labels.csv");

    int messages_extracted =
        file_exists("extracted/messages.txt") &&
        file_has_current_nonce("extracted/messages.txt", nonce) &&
        file_contains("extracted/messages.txt", "EXTRACT,stego_01.wav,HI_ALICE") &&
        file_contains("extracted/messages.txt", "EXTRACT,stego_02.wav,ECHO_LAB") &&
        file_contains("extracted/messages.txt", "EXTRACT,stego_03.wav,PTIT2026") &&
        log_has_step("extract_echo file=stego_03.wav");

    if (dataset_reviewed) {
        emit_hidden_token("dataset_reviewed");
    }

    if (detector_code_reviewed) {
        emit_hidden_token("detector_code_reviewed");
    }

    if (cepstrum_analysis) {
        emit_hidden_token("cepstrum_analysis_completed");
    }

    if (autocorr_analysis) {
        emit_hidden_token("autocorr_analysis_completed");
    }

    if (delaypair_analysis) {
        emit_hidden_token("delaypair_analysis_completed");
    }

    if (extraction_confidence_analysis) {
        emit_hidden_token("extraction_confidence_analysis_completed");
    }

    if (benchmark_report) {
        emit_hidden_token("benchmark_report_completed");
    }

    if (messages_extracted) {
        emit_hidden_token("messages_extracted");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
