#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step

MAP = {
    "cepstrum": "detect_cepstrum.py",
    "autocorr": "detect_autocorr.py",
    "delay_pair": "detect_delay_pair.py",
    "extraction_confidence": "detect_extraction_confidence.py"
}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("detector", choices=MAP.keys())
    args = p.parse_args()

    nonce = read_nonce()
    path = MAP[args.detector]

    print(f"Run nonce: {nonce}")
    print(f"Reviewing detector: {args.detector}")
    print(f"Source file: {path}")
    print("-" * 60)

    with open(path, "r", encoding="utf-8") as f:
        print(f.read())

    write_step(f"review_code detector={args.detector} file={path} nonce={nonce}")

if __name__ == "__main__":
    main()
