#!/bin/bash
cd "$HOME"

mkdir -p "$HOME/.local"

if [ ! -f "$HOME/.lab_nonce" ]; then
    date +%s%N | sha256sum | awk '{print $1}' > "$HOME/.lab_nonce"
fi

if [ ! -d dataset ] || [ ! -f labels.csv ]; then
    python3 generate_dataset.py > /tmp/generate_dataset.log 2>&1
fi

chmod +x generate_dataset.py 2>/dev/null
chmod +x detect_cepstrum.py 2>/dev/null
chmod +x detect_autocorr.py 2>/dev/null
chmod +x detect_delay_pair.py 2>/dev/null
chmod +x detect_extraction_confidence.py 2>/dev/null
chmod +x evaluate_results.py 2>/dev/null
chmod +x extract_echo.py 2>/dev/null
chmod +x review_detector.py 2>/dev/null
chmod +x review_dataset.py 2>/dev/null
