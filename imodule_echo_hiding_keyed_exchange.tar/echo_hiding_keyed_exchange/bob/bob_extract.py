#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_text, key_fingerprint
from echo_keyed import read_wav, extract_keyed

def read_expected_hash(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", default="received_stego.wav")
    p.add_argument("-o", "--output", required=True)
    p.add_argument("--key", required=True)
    p.add_argument("--chars", type=int, default=12)
    p.add_argument("--hash-file", default="received_message_hash.txt")
    p.add_argument("--report", required=True)
    p.add_argument("--mode", choices=["wrong", "correct"], required=True)
    args = p.parse_args()

    nonce = read_nonce()

    expected_hash = read_expected_hash(args.hash_file)

    rate, audio = read_wav(args.input)
    extracted = extract_keyed(audio, args.key, args.chars)
    actual_hash = sha256_text(extracted)

    extracted_ok = actual_hash == expected_hash

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(extracted + "\n")

    with open(args.report, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Output: {args.output}\n")
        f.write(f"Mode: {args.mode}\n")
        f.write(f"Key fingerprint: {key_fingerprint(args.key)}\n")
        f.write(f"Extracted text: {extracted}\n")
        f.write(f"Expected hash: {expected_hash}\n")
        f.write(f"Actual hash: {actual_hash}\n")
        f.write(f"Extracted OK: {'yes' if extracted_ok else 'no'}\n")

        if args.mode == "wrong":
            f.write(f"Wrong key rejected: {'yes' if not extracted_ok else 'no'}\n")
        else:
            f.write(f"Extraction completed: {'yes' if extracted_ok else 'no'}\n")

    write_step(
        f"bob_extract input={args.input} output={args.output} report={args.report} "
        f"mode={args.mode} nonce={nonce} extracted_ok={'yes' if extracted_ok else 'no'}"
    )

    print("Bob extraction completed.")
    print(f"Report: {args.report}")
    print(f"Extracted OK: {'yes' if extracted_ok else 'no'}")

if __name__ == "__main__":
    main()
