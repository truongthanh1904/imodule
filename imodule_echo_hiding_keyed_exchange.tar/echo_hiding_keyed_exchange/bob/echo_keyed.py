#!/usr/bin/env python3
import wave
import hashlib
import numpy as np

def read_wav(path):
    with wave.open(path, "rb") as wf:
        ch = wf.getnchannels()
        sw = wf.getsampwidth()
        rate = wf.getframerate()
        frames = wf.readframes(wf.getnframes())

    if sw != 2:
        raise ValueError("Only 16-bit PCM WAV is supported.")

    x = np.frombuffer(frames, dtype=np.int16).astype(np.float64)
    if ch > 1:
        x = x.reshape(-1, ch).mean(axis=1)

    return rate, x / 32768.0

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        value = 0
        for b in byte:
            value = (value << 1) | b
        chars.append(value)
    return bytes(chars).decode("utf-8", errors="replace")

def seed_from_key(key):
    digest = hashlib.sha256(key.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")

def keyed_permutation(key, count):
    rng = np.random.default_rng(seed_from_key(key))
    return rng.permutation(count)

def real_cepstrum(x):
    x = x - np.mean(x)
    x = x * np.hanning(len(x))

    nfft = 1
    while nfft < len(x):
        nfft *= 2

    spec = np.fft.rfft(x, n=nfft)
    log_mag = np.log(np.abs(spec) + 1e-12)
    return np.fft.irfft(log_mag, n=nfft)

def extract_keyed(audio, key, chars, delay0=50, delay1=75):
    bit_count = chars * 8
    seg_len = len(audio) // bit_count
    order = keyed_permutation(key, bit_count)

    bits = []

    for bit_index, seg_index in enumerate(order):
        start = int(seg_index) * seg_len
        end = start + seg_len
        seg = audio[start:end]

        cep = real_cepstrum(seg)
        s0 = abs(cep[delay0])
        s1 = abs(cep[delay1])

        bits.append(1 if s1 > s0 else 0)

    return bits_to_text(bits)
