#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_text

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-m", "--message", default="bob_message.txt")
    p.add_argument("-r", "--reference-hash", default="received_message_hash.txt")
    p.add_argument("-o", "--output", default="verify_report.txt")
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.message, "r", encoding="utf-8", errors="replace") as f:
        message = f.read().strip()

    with open(args.reference_hash, "r", encoding="utf-8") as f:
        expected_hash = f.read().strip()

    actual_hash = sha256_text(message)
    verified = actual_hash == expected_hash

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Message file: {args.message}\n")
        f.write(f"Reference hash: {expected_hash}\n")
        f.write(f"Actual hash: {actual_hash}\n")
        f.write(f"Integrity verified: {'yes' if verified else 'no'}\n")

    write_step(
        f"verify_message message={args.message} output={args.output} "
        f"nonce={nonce} verified={'yes' if verified else 'no'}"
    )

    print("Integrity verification completed.")
    print(f"Integrity verified: {'yes' if verified else 'no'}")

if __name__ == "__main__":
    main()
