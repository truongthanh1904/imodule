#!/usr/bin/env python3
import os
import hashlib

def read_nonce():
    try:
        with open(".lab_nonce", "r", encoding="utf-8") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "missing_nonce"

def write_step(line):
    try:
        os.makedirs(".local", exist_ok=True)
        with open(".local/lab_steps.log", "a", encoding="utf-8") as log:
            log.write(line + "\n")
    except Exception:
        pass

def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def key_fingerprint(key):
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
