#include <stdio.h>
#include <string.h>

int file_exists(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;
    fclose(fp);
    return 1;
}

int file_contains(const char *filename, const char *needle) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    char line[2048];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, needle)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

int read_first_line(const char *filename, char *buf, int size) {
    FILE *fp = fopen(filename, "r");
    if (!fp) return 0;

    if (!fgets(buf, size, fp)) {
        fclose(fp);
        return 0;
    }

    fclose(fp);
    buf[strcspn(buf, "\r\n")] = 0;
    return strlen(buf) > 0;
}

int file_has_nonce(const char *filename, const char *nonce) {
    char expected[512];
    snprintf(expected, sizeof(expected), "Run nonce: %s", nonce);
    return file_contains(filename, expected);
}

int log_has_step(const char *keyword) {
    FILE *fp = fopen(".local/lab_steps.log", "r");
    if (!fp) return 0;

    char line[2048];
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, keyword)) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void emit_hidden_token(const char *token) {
    printf("%s\r\033[K", token);
}

int main() {
    char bob_nonce[256] = "";
    char alice_nonce[256] = "";

    if (!read_first_line(".lab_nonce", bob_nonce, sizeof(bob_nonce))) {
        emit_hidden_token("missing_bob_nonce");
        printf("Ket qua da duoc ghi nhan.\n");
        printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");
        return 0;
    }

    int has_alice_nonce = read_first_line("received_alice_nonce.txt", alice_nonce, sizeof(alice_nonce));

    int alice_embedding =
        has_alice_nonce &&
        file_exists("received_stego.wav") &&
        file_exists("received_embed_report.txt") &&
        file_has_nonce("received_embed_report.txt", alice_nonce) &&
        file_contains("received_embed_report.txt", "Embedding completed: yes");

    int transfer_completed =
        has_alice_nonce &&
        file_exists("received_stego.wav") &&
        file_exists("received_embed_report.txt") &&
        file_exists("received_message_hash.txt") &&
        file_exists("received_alice_nonce.txt") &&
        file_exists("transfer_report.txt") &&
        file_has_nonce("transfer_report.txt", alice_nonce) &&
        file_contains("transfer_report.txt", "Transfer completed: yes");

    int wrong_key_rejected =
        file_exists("wrong_key_report.txt") &&
        file_has_nonce("wrong_key_report.txt", bob_nonce) &&
        file_contains("wrong_key_report.txt", "Mode: wrong") &&
        file_contains("wrong_key_report.txt", "Wrong key rejected: yes") &&
        log_has_step("mode=wrong");

    int bob_extraction =
        file_exists("bob_extract_report.txt") &&
        file_exists("bob_message.txt") &&
        file_has_nonce("bob_extract_report.txt", bob_nonce) &&
        file_contains("bob_extract_report.txt", "Mode: correct") &&
        file_contains("bob_extract_report.txt", "Extraction completed: yes") &&
        log_has_step("mode=correct");

    int integrity_verified =
        file_exists("verify_report.txt") &&
        file_has_nonce("verify_report.txt", bob_nonce) &&
        file_contains("verify_report.txt", "Integrity verified: yes") &&
        log_has_step("verify_message message=bob_message.txt");

    if (alice_embedding) {
        emit_hidden_token("alice_embedding_completed");
    }

    if (transfer_completed) {
        emit_hidden_token("transfer_completed");
    }

    if (wrong_key_rejected) {
        emit_hidden_token("wrong_key_rejected");
    }

    if (bob_extraction) {
        emit_hidden_token("bob_extraction_completed");
    }

    if (integrity_verified) {
        emit_hidden_token("integrity_verified");
    }

    printf("Ket qua da duoc ghi nhan.\n");
    printf("Hay quay lai terminal chinh va chay lenh checkwork.\n");

    return 0;
}
