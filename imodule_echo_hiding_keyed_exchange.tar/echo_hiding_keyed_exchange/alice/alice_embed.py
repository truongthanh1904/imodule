#!/usr/bin/env python3
import argparse
from lab_common import read_nonce, write_step, sha256_file, sha256_text, key_fingerprint
from echo_keyed import read_wav, write_wav, embed_keyed

def main():
    p = argparse.ArgumentParser()
    p.add_argument("-i", "--input", default="cover.wav")
    p.add_argument("-m", "--message", default="secret.txt")
    p.add_argument("-o", "--output", default="stego_keyed.wav")
    p.add_argument("--key", required=True)
    p.add_argument("--alpha", type=float, default=0.42)
    args = p.parse_args()

    nonce = read_nonce()

    with open(args.message, "r", encoding="utf-8") as f:
        message = f.read().strip()

    rate, audio = read_wav(args.input)
    stego, seg_len, bit_count = embed_keyed(audio, message, args.key, args.alpha)
    write_wav(args.output, rate, stego)

    msg_hash = sha256_text(message)
    stego_hash = sha256_file(args.output)

    with open("message_hash.txt", "w", encoding="utf-8") as f:
        f.write(msg_hash + "\n")

    with open("alice_embed_report.txt", "w", encoding="utf-8") as f:
        f.write(f"Run nonce: {nonce}\n")
        f.write(f"Input: {args.input}\n")
        f.write(f"Output: {args.output}\n")
        f.write(f"Message length: {len(message)}\n")
        f.write(f"Embedded bits: {bit_count}\n")
        f.write(f"Segment length: {seg_len}\n")
        f.write(f"Key fingerprint: {key_fingerprint(args.key)}\n")
        f.write(f"Message hash: {msg_hash}\n")
        f.write(f"Stego hash: {stego_hash}\n")
        f.write("Embedding completed: yes\n")

    write_step(
        f"alice_embed input={args.input} output={args.output} "
        f"nonce={nonce} keyfp={key_fingerprint(args.key)} completed=yes"
    )

    print("Alice embedding completed.")
    print("Output: stego_keyed.wav")
    print("Report: alice_embed_report.txt")
    print("Hash file: message_hash.txt")

if __name__ == "__main__":
    main()
