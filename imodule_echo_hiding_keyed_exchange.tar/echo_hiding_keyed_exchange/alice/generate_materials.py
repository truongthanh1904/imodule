#!/usr/bin/env python3
import wave
import numpy as np

RATE = 16000
DURATION = 8.0

def normalize(x, peak=0.85):
    m = np.max(np.abs(x))
    if m == 0:
        return x
    return x / m * peak

def write_wav(path, x):
    x = normalize(x)
    pcm = np.int16(np.clip(x, -1, 1) * 32767)

    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())

def main():
    rng = np.random.default_rng(6060)
    n = int(RATE * DURATION)
    t = np.arange(n) / RATE

    x = (
        0.38 * np.sin(2 * np.pi * 440 * t) +
        0.24 * np.sin(2 * np.pi * 880 * t) +
        0.12 * np.sin(2 * np.pi * 1760 * t)
    )

    envelope = 0.75 + 0.25 * np.sin(2 * np.pi * 1.4 * t)
    x = x * envelope
    x = x + 0.025 * rng.standard_normal(n)

    write_wav("cover.wav", x)

    with open("secret.txt", "w", encoding="utf-8") as f:
        f.write("ALICE_TO_BOB")

    print("Generated cover.wav and secret.txt")

if __name__ == "__main__":
    main()
