#!/bin/bash

set -e

BOB_HOST="${1:-bob}"
BOB_USER="ubuntu"
BOB_PASS="password123"

required_files="stego_keyed.wav alice_embed_report.txt message_hash.txt .lab_nonce"

for f in $required_files; do
    if [ ! -f "$f" ]; then
        echo "Missing required file: $f"
        exit 1
    fi
done

cp .lab_nonce alice_session_nonce.txt

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    stego_keyed.wav "$BOB_USER@$BOB_HOST:/home/ubuntu/received_stego.wav"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    alice_embed_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_embed_report.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    message_hash.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_message_hash.txt"

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    alice_session_nonce.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/received_alice_nonce.txt"

cat > transfer_report.txt <<EOF
Run nonce: $(cat .lab_nonce)
Transfer method: scp
Destination: bob
Transferred stego: yes
Transferred embed report: yes
Transferred message hash: yes
Transferred alice nonce: yes
Transfer completed: yes
EOF

sshpass -p "$BOB_PASS" scp -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    transfer_report.txt "$BOB_USER@$BOB_HOST:/home/ubuntu/transfer_report.txt"

echo "SCP transfer to Bob completed."
